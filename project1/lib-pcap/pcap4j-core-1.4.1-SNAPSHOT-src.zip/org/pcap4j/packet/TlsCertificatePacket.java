/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsCertificatePacket extends TlsAbstractCertificatePacket {

  /**
   *
   */
  private static final long serialVersionUID = 6466838998883831464L;

  private final TlsCertificateHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsCertificatePacket object.
   * @throws IllegalRawDataException
   */
  public static TlsCertificatePacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsCertificatePacket(rawData, offset, length);
  }

  private TlsCertificatePacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsCertificateHeader(rawData, offset, length);
  }

  private TlsCertificatePacket(Builder builder) {
    super(builder);
    this.header = new TlsCertificateHeader(builder);
  }

  @Override
  public TlsCertificateHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends TlsAbstractCertificatePacket.Builder {

    /**
     *
     */
    public Builder() {}

    private Builder(TlsCertificatePacket packet) {
      super(packet);
    }

    @Override
    public Builder certificateList(List<byte[]> certificateList) {
      super.certificateList(certificateList);
      return this;
    }

    @Override
    public TlsCertificatePacket build() {
      return new TlsCertificatePacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsCertificateHeader extends TlsAbstractCertificateHeader {

    /*
     * opaque ASN.1Cert<1..2^24-1>;
     * struct {
     *
     *     ASN.1Cert certificate_list<0..2^24-1>;
     *
     * } Certificate;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -3601960791495655250L;

    private TlsCertificateHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      super(rawData, offset, length);
    }

    private TlsCertificateHeader(Builder builder) {
      super(builder);
    }

    @Override
    protected String getHeaderName() {
      return "TLS Certificate Header";
    }

  }

}
