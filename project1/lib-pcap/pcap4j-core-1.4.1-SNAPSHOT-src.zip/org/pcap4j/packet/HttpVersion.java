/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.io.Serializable;
import org.pcap4j.util.ByteArrays;


/**
 * @author Kaito Yamada
 * @since pcap4j 1.2.1
 */
public final class HttpVersion implements Serializable, Comparable<HttpVersion> {

  /*
   * ftp://www.ietf.org/rfc/rfc2616.txt
   *
   * HTTP-Version   = "HTTP" "/" 1*DIGIT "." 1*DIGIT
   */

  /**
   *
   */
  private static final long serialVersionUID = 2996823423835993400L;

  private final int major;
  private final int minor;

  /**
   * Constructor.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @throws IllegalRawDataException
   */
  public HttpVersion(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);

    if (length < 8) {
      throw new IllegalRawDataException(
              "rawData length must be more than 7 but: " + length
            );
    }

    String verStr = new String(rawData, offset, length);
    if (!verStr.startsWith("HTTP/")) {
      throw new IllegalRawDataException(
              "Http version must start with HTTP/ but: " + verStr
            );
    }

    int dotOffset = verStr.indexOf('.');
    if (dotOffset < 0) {
      throw new IllegalRawDataException(
              "Http version must be like HTTP/major.minor but no dot is found in verStr: "
                + verStr
            );
    }

    String majorStr = verStr.substring("HTTP/".length(), dotOffset);
    if (majorStr.startsWith("-")) {
      throw new IllegalRawDataException("major version must be positive but: " + majorStr);
    }
    try {
      this.major = Integer.parseInt(majorStr);
    } catch (NumberFormatException e) {
      throw new IllegalRawDataException("Illegal major version: " + majorStr);
    }

    int spaceOffset = verStr.indexOf(' ');
    String minorStr;
    if (spaceOffset > 0) {
      minorStr = verStr.substring("HTTP/".length() + majorStr.length() + 1, spaceOffset);
    }
    else {
      minorStr = verStr.substring("HTTP/".length() + majorStr.length() + 1);
    }

    if (minorStr.startsWith("-")) {
      throw new IllegalRawDataException("minor version must be positive but: " + minorStr);
    }
    try {
      this.minor = Integer.parseInt(minorStr);
    } catch (NumberFormatException e) {
      throw new IllegalRawDataException("Illegal minor version: " + minorStr);
    }
  }

  /**
   * @return major
   */
  public int getMajor() {
    return major;
  }

  /**
   * @return minor
   */
  public int getMinor() {
    return minor;
  }


  /**
   *
   * @return length
   */
  public int length() {
    return toString().length();
  }

  /**
   *
   * @return rawData
   */
  public byte[] getRawData() {
    return toString().getBytes();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) { return true; }
    if (!this.getClass().isInstance(obj)) { return false; }
    return    ((HttpVersion)obj).major == this.major
           && ((HttpVersion)obj).minor == this.minor;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + major;
    result = prime * result + minor;
    return result;
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder(15);
    sb.append("HTTP/")
      .append(major)
      .append(".")
      .append(minor);
    return sb.toString();
  }

  @Override
  public int compareTo(HttpVersion o) {
    Float myVer = Float.valueOf(major + "." + minor);
    Float otherVer = Float.valueOf(o.major + "." + o.minor);
    return myVer.compareTo(otherVer);
  }

}
