/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.Collections;
import java.util.List;
import org.pcap4j.packet.factory.PacketFactories;
import org.pcap4j.packet.namednumber.TlsKeyExchangeAlgorithm;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
abstract class TlsAbstractKeyExchangePacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = -4235558326329203570L;

  private final Packet payload;

  protected TlsAbstractKeyExchangePacket(
    byte[] rawData, int offset, int length, TlsAbstractKeyExchangeHeader header
  ) throws IllegalRawDataException {
    this.payload
      = PacketFactories.getFactory(Packet.class, TlsKeyExchangeAlgorithm.class)
          .newInstance(
             rawData,
             offset + header.length(),
             length,
             header.getKeyExchangeAlgorithm()
           );
  }

  protected TlsAbstractKeyExchangePacket(Builder builder) {
    if (
         builder == null
      || builder.keyExchangeAlgorithm == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.keyExchangeAlgorithm: ").append(builder.keyExchangeAlgorithm);
      throw new NullPointerException(sb.toString());
    }

    this.payload = builder.payloadBuilder != null ? builder.payloadBuilder.build() : null;
  }

  @Override
  public abstract TlsAbstractKeyExchangeHeader getHeader();

  @Override
  public Packet getPayload() {
    return payload;
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  static abstract class Builder extends AbstractBuilder {

    private TlsKeyExchangeAlgorithm keyExchangeAlgorithm;
    private Packet.Builder payloadBuilder;

    /**
     *
     */
    protected Builder() {}

    protected Builder(TlsAbstractKeyExchangePacket packet) {
      this.keyExchangeAlgorithm = packet.getHeader().keyExchangeAlgorithm;
      this.payloadBuilder = packet.payload != null ? packet.payload.getBuilder() : null;
    }

    /**
     *
     * @param keyExchangeAlgorithm
     * @return this Builder object for method chaining.
     */
    public Builder keyExchangeAlgorithm(TlsKeyExchangeAlgorithm keyExchangeAlgorithm) {
      this.keyExchangeAlgorithm = keyExchangeAlgorithm;
      return this;
    }

    @Override
    public Builder payloadBuilder(Packet.Builder payloadBuilder) {
      this.payloadBuilder = payloadBuilder;
      return this;
    }

    @Override
    public Packet.Builder getPayloadBuilder() {
      return payloadBuilder;
    }

  }

  /**
   * Abstract pseudo header to hold a key exchange algorithm.
   *
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  static abstract class TlsAbstractKeyExchangeHeader extends AbstractHeader {

    /**
     *
     */
    private static final long serialVersionUID = 8571130598422344100L;

    private final TlsKeyExchangeAlgorithm keyExchangeAlgorithm;

    protected TlsAbstractKeyExchangeHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      this.keyExchangeAlgorithm = TlsKeyExchangeAlgorithm.DIFFIE_HELLMAN_SERVER; // TODO TLS session
    }

    protected TlsAbstractKeyExchangeHeader(Builder builder) {
      this.keyExchangeAlgorithm = builder.keyExchangeAlgorithm;
    }

    /**
     *
     * @return keyExchangeAlgorithm
     */
    public TlsKeyExchangeAlgorithm getKeyExchangeAlgorithm() {
      return keyExchangeAlgorithm;
    }

    @Override
    protected List<byte[]> getRawFields() {
      return Collections.emptyList();
    }

    @Override
    public int length() {
      return 0;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[")
        .append(getHeaderName())
        .append(" (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Key Exchange Algorithm: ")
        .append(keyExchangeAlgorithm.name())
        .append(ls);

      return sb.toString();
    }

    protected abstract String getHeaderName();

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsAbstractKeyExchangeHeader other = (TlsAbstractKeyExchangeHeader)obj;
      return keyExchangeAlgorithm.equals(other.keyExchangeAlgorithm);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + keyExchangeAlgorithm.hashCode();
      return result;
    }

  }

}
