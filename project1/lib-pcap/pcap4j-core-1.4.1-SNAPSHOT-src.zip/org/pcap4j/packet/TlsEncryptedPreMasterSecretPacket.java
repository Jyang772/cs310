/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsEncryptedPreMasterSecretPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 6084807528468443765L;

  private final TlsEncryptedPreMasterSecretHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsEncryptedPreMasterSecretPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsEncryptedPreMasterSecretPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsEncryptedPreMasterSecretPacket(rawData, offset, length);
  }

  private TlsEncryptedPreMasterSecretPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsEncryptedPreMasterSecretHeader(rawData, offset, length);
  }

  private TlsEncryptedPreMasterSecretPacket(Builder builder) {
    if (
         builder == null
      || builder.encryptedPreMasterSecret == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.encryptedPreMasterSecret: ").append(builder.encryptedPreMasterSecret);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsEncryptedPreMasterSecretHeader(builder);
  }

  @Override
  public TlsEncryptedPreMasterSecretHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private byte[] encryptedPreMasterSecret;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsEncryptedPreMasterSecretPacket packet) {
      this.encryptedPreMasterSecret = packet.header.encryptedPreMasterSecret;
    }

    /**
     *
     * @param encryptedPreMasterSecret
     * @return this Builder object for method chaining.
     */
    public Builder encryptedPreMasterSecret(byte[] encryptedPreMasterSecret) {
      this.encryptedPreMasterSecret = encryptedPreMasterSecret;
      return this;
    }

    @Override
    public TlsEncryptedPreMasterSecretPacket build() {
      return new TlsEncryptedPreMasterSecretPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsEncryptedPreMasterSecretHeader extends AbstractHeader {

    /*
     * struct {
     *     ProtocolVersion client_version;
     *     opaque random[46];
     * } PreMasterSecret;
     *
     * struct {
     *     public-key-encrypted PreMasterSecret pre_master_secret;
     * } EncryptedPreMasterSecret;
     *
     * In public key encryption, a public key algorithm is used to encrypt
     * data in such a way that it can be decrypted only with the matching
     * private key. A public-key-encrypted element is encoded as an opaque
     * vector <0..2^16-1>, where the length is specified by the signing
     * algorithm and key.
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -4609035363899256532L;

    private static final int MIN_TLS_ENCRYPTED_PRE_MASTER_SECRET_HEADER_SIZE
      = 2;

    private final byte[] encryptedPreMasterSecret;

    private TlsEncryptedPreMasterSecretHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < MIN_TLS_ENCRYPTED_PRE_MASTER_SECRET_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsEncryptedPreMasterSecretHeader (")
          .append(MIN_TLS_ENCRYPTED_PRE_MASTER_SECRET_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      int curRelOffset = 0;
      int dataLen = ByteArrays.getInt(rawData, curRelOffset + offset, 2);
      curRelOffset += 2;
      if (curRelOffset + dataLen > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get dh_p. ")
          .append("The data is too short to build an TlsEncryptedPreMasterSecretHeader (")
          .append(curRelOffset + dataLen)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (dataLen > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("pre_master_secret length must be less than (1 << 16) but is: ")
          .append(dataLen)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.encryptedPreMasterSecret
        = ByteArrays.getSubArray(rawData, curRelOffset + offset, dataLen);
    }

    private TlsEncryptedPreMasterSecretHeader(Builder builder) {
      this.encryptedPreMasterSecret = ByteArrays.clone(builder.encryptedPreMasterSecret);
    }

    /**
     *
     * @return encryptedPreMasterSecret
     */
    public byte[] getEncryptedPreMasterSecret() {
      return ByteArrays.clone(encryptedPreMasterSecret);
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray((short)encryptedPreMasterSecret.length));
      rawFields.add(encryptedPreMasterSecret);
      return rawFields;
    }

    @Override
    public int length() {
      return encryptedPreMasterSecret.length + 2;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Encrypted Pre Master Secret Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Encrypted Pre Master Secret: ")
        .append(ByteArrays.toHexString(encryptedPreMasterSecret, " "))
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsEncryptedPreMasterSecretHeader other = (TlsEncryptedPreMasterSecretHeader)obj;
      return Arrays.equals(encryptedPreMasterSecret, other.encryptedPreMasterSecret);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + Arrays.hashCode(encryptedPreMasterSecret);
      return result;
    }

  }

}
