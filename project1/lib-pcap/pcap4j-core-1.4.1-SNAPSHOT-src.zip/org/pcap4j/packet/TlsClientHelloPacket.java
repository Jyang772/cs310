/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import static org.pcap4j.util.ByteArrays.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.packet.namednumber.TlsCipherSuite;
import org.pcap4j.packet.namednumber.TlsCompressionMethod;
import org.pcap4j.packet.namednumber.TlsProtocolVersion;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsClientHelloPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 4048392030587838562L;

  private final TlsClientHelloHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsClientHelloPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsClientHelloPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsClientHelloPacket(rawData, offset, length);
  }

  private TlsClientHelloPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsClientHelloHeader(rawData, offset, length);
  }

  private TlsClientHelloPacket(Builder builder) {
    if (
         builder == null
      || builder.clientVersion == null
      || builder.randomBytes == null
      || builder.sessionId == null
      || builder.cipherSuites == null
      || builder.compressionMethods == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.clientVersion: ").append(builder.clientVersion)
        .append(" builder.randomBytes: ").append(builder.randomBytes)
        .append(" builder.sessionId: ").append(builder.sessionId)
        .append(" builder.cipherSuites: ").append(builder.cipherSuites)
        .append(" builder.compressionMethods: ").append(builder.compressionMethods);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsClientHelloHeader(builder);
  }

  @Override
  public TlsClientHelloHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private TlsProtocolVersion clientVersion;
    private int gmtUnixTime;
    private byte[] randomBytes;
    private byte[] sessionId;
    private List<TlsCipherSuite> cipherSuites;
    private List<TlsCompressionMethod> compressionMethods;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsClientHelloPacket packet) {
      this.clientVersion = packet.header.clientVersion;
      this.gmtUnixTime = packet.header.gmtUnixTime;
      this.randomBytes = packet.header.randomBytes;
      this.sessionId = packet.header.sessionId;
      this.cipherSuites = packet.header.cipherSuites;
      this.compressionMethods = packet.header.compressionMethods;
    }

    /**
     *
     * @param clientVersion
     * @return this Builder object for method chaining.
     */
    public Builder clientVersion(TlsProtocolVersion clientVersion) {
      this.clientVersion = clientVersion;
      return this;
    }

    /**
     *
     * @param gmtUnixTime
     * @return this Builder object for method chaining.
     */
    public Builder gmtUnixTime(int gmtUnixTime) {
      this.gmtUnixTime = gmtUnixTime;
      return this;
    }

    /**
     *
     * @param randomBytes
     * @return this Builder object for method chaining.
     */
    public Builder randomBytes(byte[] randomBytes) {
      this.randomBytes = randomBytes;
      return this;
    }

    /**
     *
     * @param sessionId
     * @return this Builder object for method chaining.
     */
    public Builder sessionId(byte[] sessionId) {
      this.sessionId = sessionId;
      return this;
    }

    /**
     *
     * @param cipherSuites
     * @return this Builder object for method chaining.
     */
    public Builder cipherSuites(List<TlsCipherSuite> cipherSuites) {
      this.cipherSuites = cipherSuites;
      return this;
    }

    /**
     *
     * @param compressionMethods
     * @return this Builder object for method chaining.
     */
    public Builder compressionMethods(List<TlsCompressionMethod> compressionMethods) {
      this.compressionMethods = compressionMethods;
      return this;
    }

    @Override
    public TlsClientHelloPacket build() {
      return new TlsClientHelloPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsClientHelloHeader extends AbstractHeader {

    /*
     * struct {
     *
     *     uint32 gmt_unix_time;
     *     opaque random_bytes[28];
     *
     * } Random;
     * opaque SessionID<0..32>;
     * uint8 CipherSuite[2];
     * enum { null(0), (255) } CompressionMethod;
     * struct {
     *
     *     ProtocolVersion client_version;
     *     Random random;
     *     SessionID session_id;
     *     CipherSuite cipher_suites<2..2^16-1>;
     *     CompressionMethod compression_methods<1..2^8-1>;
     *
     * } ClientHello;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -5762182640976832944L;

    private static final int CLIENT_VERSION_OFFSET
      = 0;
    private static final int CLIENT_VERSION_SIZE
      = SHORT_SIZE_IN_BYTES;
    private static final int GMT_UNIX_TIME_OFFSET
      = CLIENT_VERSION_OFFSET + CLIENT_VERSION_SIZE;
    private static final int GMT_UNIX_TIME_SIZE
      = INT_SIZE_IN_BYTES;
    private static final int RANDOM_BYTES_OFFSET
      = GMT_UNIX_TIME_OFFSET + GMT_UNIX_TIME_SIZE;
    private static final int RANDOM_BYTES_LENGTH
      = 28;
    private static final int SESSION_ID_OFFSET
      = RANDOM_BYTES_OFFSET + RANDOM_BYTES_LENGTH;

    private final TlsProtocolVersion clientVersion;
    private final int gmtUnixTime;
    private final byte[] randomBytes;
    private final byte[] sessionId;
    private final List<TlsCipherSuite> cipherSuites = new ArrayList<TlsCipherSuite>();
    private final List<TlsCompressionMethod> compressionMethods
      = new ArrayList<TlsCompressionMethod>();

    private TlsClientHelloHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < SESSION_ID_OFFSET + 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsClientHelloHeader (")
          .append(SESSION_ID_OFFSET + 1)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.clientVersion = TlsProtocolVersion.getInstance(ByteArrays.getShort(rawData, offset));
      this.gmtUnixTime
        = ByteArrays.getInt(rawData, GMT_UNIX_TIME_OFFSET + offset);
      this.randomBytes
        = ByteArrays.getSubArray(rawData, RANDOM_BYTES_OFFSET + offset, RANDOM_BYTES_LENGTH);

      int curRelOffset = SESSION_ID_OFFSET;
      int sessionIdLength = 0xFF & rawData[curRelOffset + offset];
      curRelOffset++;
      if (curRelOffset + sessionIdLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get sessionId. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + sessionIdLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (sessionIdLength == 0) {
        this.sessionId = new byte[0];
      }
      else if (sessionIdLength > 32) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("sessionId length must be less than 33 but is: ")
          .append(sessionIdLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      else {
        this.sessionId
          = ByteArrays.getSubArray(rawData, curRelOffset + offset, sessionIdLength);
      }
      curRelOffset += sessionId.length;

      if (curRelOffset + SHORT_SIZE_IN_BYTES > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get cipherSuitesLength. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + SHORT_SIZE_IN_BYTES)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      int cipherSuitesLength = 0xFFFF & ByteArrays.getShort(rawData, curRelOffset + offset);
      curRelOffset += 2;
      if (cipherSuitesLength % 2 != 0) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("cipher_suites length must be a multiple of 2 but is: ")
          .append(cipherSuitesLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (cipherSuitesLength < 2) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("cipher_suites length must be more than 1 but is: ")
          .append(cipherSuitesLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (cipherSuitesLength > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("cipher_suites length must be less than (1 << 16) but is: ")
          .append(cipherSuitesLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (curRelOffset + cipherSuitesLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get cipher_suites. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + cipherSuitesLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      for (int i = 0; i < cipherSuitesLength; i += 2) {
        cipherSuites.add(
          TlsCipherSuite.getInstance(
            ByteArrays.getShort(rawData, curRelOffset + i + offset)
          )
        );
      }
      curRelOffset += cipherSuites.size() * 2;

      if (curRelOffset + BYTE_SIZE_IN_BYTES > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get compressionMethodsLength. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + BYTE_SIZE_IN_BYTES)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      int compressionMethodsLength = 0xFF & ByteArrays.getByte(rawData, curRelOffset + offset);
      curRelOffset++;
      if (compressionMethodsLength < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("compression_methods length must be more than 0 but is: ")
          .append(compressionMethodsLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (compressionMethodsLength > (1 << 8) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("compression_methods length must be less than (1 << 8) but is: ")
          .append(compressionMethodsLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (curRelOffset + compressionMethodsLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get compression_methods. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + compressionMethodsLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      for (int i = 0; i < compressionMethodsLength; i++) {
        compressionMethods.add(
          TlsCompressionMethod.getInstance(
            ByteArrays.getByte(rawData, curRelOffset + i + offset)
          )
        );
      }
    }

    private TlsClientHelloHeader(Builder builder) {
      if (builder.sessionId.length > 32) {
        throw new IllegalArgumentException(
                "sessionId length must be less than 33 but is: " + builder.sessionId.length
              );
      }
      if (builder.cipherSuites.size() > ((1 << 16) - 1) / 2) {
        throw new IllegalArgumentException(
                "cipherSuites size must be less than ((1 << 16) - 1) / 2 but is: "
                  + builder.cipherSuites.size()
              );
      }
      if (builder.compressionMethods.size() > (1 << 8) - 1) {
        throw new IllegalArgumentException(
                "compressionMethods size must be less than (1 << 8) but is: "
                  + builder.compressionMethods.size()
              );
      }

      this.clientVersion = builder.clientVersion;
      this.gmtUnixTime = builder.gmtUnixTime;
      this.randomBytes = ByteArrays.clone(builder.randomBytes);
      this.sessionId = ByteArrays.clone(builder.sessionId);
      this.cipherSuites.addAll(builder.cipherSuites);
      this.compressionMethods.addAll(builder.compressionMethods);
    }

    /**
     * @return clientVersion
     */
    public TlsProtocolVersion getClientVersion() {
      return clientVersion;
    }

    /**
     * @return gmtUnixTime
     */
    public int getGmtUnixTime() {
      return gmtUnixTime;
    }

    /**
     * @return gmtUnixTime
     */
    public long getGmtUnixTimeAsLong() {
      return 0xFFFFFFFFL & gmtUnixTime;
    }

    /**
     * @return randomBytes
     */
    public byte[] getRandomBytes() {
      return ByteArrays.clone(randomBytes);
    }

    /**
     * @return sessionId
     */
    public byte[] getSessionId() {
      return ByteArrays.clone(sessionId);
    }

    /**
     * @return cipherSuites
     */
    public List<TlsCipherSuite> getCipherSuites() {
      return new ArrayList<TlsCipherSuite>(cipherSuites);
    }

    /**
     * @return compressionMethods
     */
    public List<TlsCompressionMethod> getCompressionMethods() {
      return new ArrayList<TlsCompressionMethod>(compressionMethods);
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray(clientVersion.value()));
      rawFields.add(ByteArrays.toByteArray(gmtUnixTime));
      rawFields.add(randomBytes);
      rawFields.add(ByteArrays.toByteArray((byte)sessionId.length));
      rawFields.add(sessionId);
      rawFields.add(ByteArrays.toByteArray((short)(cipherSuites.size() * 2)));
      for (TlsCipherSuite cs: cipherSuites) {
        rawFields.add(ByteArrays.toByteArray(cs.value()));
      }
      rawFields.add(ByteArrays.toByteArray((byte)compressionMethods.size() * 2));
      for (TlsCompressionMethod cm: compressionMethods) {
        rawFields.add(ByteArrays.toByteArray(cm.value()));
      }
      return rawFields;
    }

    @Override
    protected int calcLength() {
      int len = SESSION_ID_OFFSET;
      len++;
      len += sessionId.length;
      len += 2;
      len += cipherSuites.size() * 2;
      len ++;
      len += compressionMethods.size();
      return len;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Client Hello Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Client Version: ")
        .append(clientVersion)
        .append(ls);
      sb.append("  GMT UNIX Time: ")
        .append(getGmtUnixTimeAsLong())
        .append(ls);
      sb.append("  Random Bytes: ")
        .append(ByteArrays.toHexString(randomBytes, " "))
        .append(ls);
      sb.append("  Session ID: ")
        .append(ByteArrays.toHexString(sessionId, " "))
        .append(ls);
      sb.append("  Cipher Suites: ")
        .append(ls);
      for (TlsCipherSuite cs: cipherSuites) {
        sb.append("    ")
          .append(cs)
          .append(ls);
      }
      sb.append("  Compression Methods: ")
        .append(ls);
      for (TlsCompressionMethod cm: compressionMethods) {
        sb.append("    ")
          .append(cm)
          .append(ls);
      }

      return sb.toString();
    }

    @Override
    protected int calcHashCode() {
      int result = super.calcHashCode();
      result = 31 * result + clientVersion.hashCode();
      result = 31 * result + gmtUnixTime;
      result = 31 * result + Arrays.hashCode(randomBytes);
      result = 31 * result + Arrays.hashCode(sessionId);
      result = 31 * result + cipherSuites.hashCode();
      result = 31 * result + compressionMethods.hashCode();
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) { return true; }
      if (getClass() != obj.getClass()) { return false; }

      TlsClientHelloHeader other = (TlsClientHelloHeader)obj;
      return
           gmtUnixTime == other.gmtUnixTime
        && Arrays.equals(sessionId, other.sessionId)
        && Arrays.equals(randomBytes, other.randomBytes)
        && cipherSuites.equals(other.cipherSuites)
        && compressionMethods.equals(other.compressionMethods)
        && clientVersion.equals(other.clientVersion);
    }

  }

}
