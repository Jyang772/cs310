/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.io.ObjectStreamException;
import java.util.Collections;
import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsHelloRequestPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 8075301046330632575L;

  private static final TlsHelloRequestPacket INSTANCE = new TlsHelloRequestPacket();

  private final TlsHelloRequestHeader header;

  private TlsHelloRequestPacket() {
    this.header = TlsHelloRequestHeader.INSTANCE;
  }

  /**
   *
   * @return the singleton instance of IpV6Pad1Option.
   */
  public static TlsHelloRequestPacket getInstance() { return INSTANCE; }

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return the singleton instance of TlsHelloRequestPacket.
   * @throws IllegalRawDataException
   */
  public static TlsHelloRequestPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return INSTANCE;
  }

  @Override
  public TlsHelloRequestHeader getHeader() {
    return header;
  }

  @Override
  @Deprecated
  public Builder getBuilder() {
    return new Builder(this);
  }

  //Override deserializer to keep singleton
  @SuppressWarnings("static-method")
  private Object readResolve() throws ObjectStreamException {
    return INSTANCE;
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  @Deprecated
  public static final class Builder extends AbstractBuilder {

    /**
     *
     */
    public Builder() {}

    private Builder(TlsHelloRequestPacket packet) {
    }

    @Override
    public TlsHelloRequestPacket build() {
      return TlsHelloRequestPacket.getInstance();
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsHelloRequestHeader extends AbstractHeader {

    /*
     * struct { } HelloRequest;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -2173416896273379616L;

    private static final TlsHelloRequestHeader INSTANCE = new TlsHelloRequestHeader();

    private TlsHelloRequestHeader() {}

    @Override
    protected List<byte[]> getRawFields() {
      return Collections.emptyList();
    }

    @Override
    public int length() {
      return 0;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Hello Request Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);

      return sb.toString();
    }

    // Override deserializer to keep singleton
    @SuppressWarnings("static-method")
    private Object readResolve() throws ObjectStreamException {
      return INSTANCE;
    }

  }

}
