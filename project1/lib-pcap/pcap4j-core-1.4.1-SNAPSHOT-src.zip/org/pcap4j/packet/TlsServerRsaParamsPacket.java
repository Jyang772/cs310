/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.packet.factory.PacketFactories;
import org.pcap4j.packet.namednumber.TlsSignatureAlgorithm;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsServerRsaParamsPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = -1446185214890233211L;

  private final TlsServerRsaParamsHeader header;
  private final Packet payload;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsServerRsaParamsPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsServerRsaParamsPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsServerRsaParamsPacket(rawData, offset, length);
  }

  private TlsServerRsaParamsPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsServerRsaParamsHeader(rawData, offset, length);

    int payloadLength = length - header.length();
    if (payloadLength != 0) { // payloadLength is positive.
      this.payload
        = PacketFactories.getFactory(Packet.class, TlsSignatureAlgorithm.class)
            .newInstance(
               rawData,
               offset + header.length(),
               payloadLength,
               header.getSignatureAlgorithm()
             );
    }
    else {
      this.payload = null;
    }
  }

  private TlsServerRsaParamsPacket(Builder builder) {
    if (
         builder == null
      || builder.rsaModulus == null
      || builder.rsaExponent == null
      || builder.signatureAlgorithm == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.rsaModulus: ").append(builder.rsaModulus)
        .append(" builder.rsaExponent: ").append(builder.rsaExponent)
        .append(" builder.signatureAlgorithm: ").append(builder.signatureAlgorithm);
      throw new NullPointerException(sb.toString());
    }

    this.payload = builder.payloadBuilder != null ? builder.payloadBuilder.build() : null;
    this.header = new TlsServerRsaParamsHeader(builder);
  }

  @Override
  public TlsServerRsaParamsHeader getHeader() {
    return header;
  }

  @Override
  public Packet getPayload() {
    return payload;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private byte[] rsaModulus;
    private byte[] rsaExponent;
    private TlsSignatureAlgorithm signatureAlgorithm;
    private Packet.Builder payloadBuilder;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsServerRsaParamsPacket packet) {
      this.rsaModulus = packet.header.rsaModulus;
      this.rsaExponent = packet.header.rsaExponent;
      this.signatureAlgorithm = packet.header.signatureAlgorithm;
      this.payloadBuilder = packet.payload != null ? packet.payload.getBuilder() : null;
    }

    /**
     *
     * @param rsaModulus
     * @return this Builder object for method chaining.
     */
    public Builder rsaModulus(byte[] rsaModulus) {
      this.rsaModulus = rsaModulus;
      return this;
    }

    /**
     *
     * @param rsaExponent
     * @return this Builder object for method chaining.
     */
    public Builder rsaExponent(byte[] rsaExponent) {
      this.rsaExponent = rsaExponent;
      return this;
    }

    /**
     *
     * @param signatureAlgorithm
     * @return this Builder object for method chaining.
     */
    public Builder signatureAlgorithm(TlsSignatureAlgorithm signatureAlgorithm) {
      this.signatureAlgorithm = signatureAlgorithm;
      return this;
    }

    @Override
    public Builder payloadBuilder(Packet.Builder payloadBuilder) {
      this.payloadBuilder = payloadBuilder;
      return this;
    }

    @Override
    public Packet.Builder getPayloadBuilder() {
      return payloadBuilder;
    }

    @Override
    public TlsServerRsaParamsPacket build() {
      return new TlsServerRsaParamsPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsServerRsaParamsHeader extends AbstractHeader {

    /*
     * struct {
     *
     *    opaque rsa_modulus<1..2^16-1>;
     *    opaque rsa_exponent<1..2^16-1>;
     *
     * } ServerRSAParams;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = 5535334046468850306L;

    private static final int TLS_SERVER_RSA_PARAMS_HEADER_MIN = 6;

    private final byte[] rsaModulus;
    private final byte[] rsaExponent;
    private final TlsSignatureAlgorithm signatureAlgorithm; // pseudo field

    private TlsServerRsaParamsHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_SERVER_RSA_PARAMS_HEADER_MIN) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsServerRsaParamsHeader (")
          .append(TLS_SERVER_RSA_PARAMS_HEADER_MIN)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      int curRelOffset = 0;
      int rsaModulusLength = ByteArrays.getInt(rawData, curRelOffset + offset, 2);
      curRelOffset += 2;
      if (curRelOffset + rsaModulusLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get rsa_modulus. ")
          .append("The data is too short to build an TlsServerRsaParamsHeader (")
          .append(curRelOffset + rsaModulusLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (rsaModulusLength < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("rsa_modulus length must be more than 0 but is: ")
          .append(rsaModulusLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (rsaModulusLength > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("rsa_modulus length must be less than (1 << 16) but is: ")
          .append(rsaModulusLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.rsaModulus = ByteArrays.getSubArray(rawData, curRelOffset + offset, rsaModulusLength);
      curRelOffset += rsaModulusLength;

      if (curRelOffset + 2 > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get rsaExponentLength. ")
          .append("The data is too short to build an TlsServerRsaParamsHeader (")
          .append(curRelOffset + 2)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      int rsaExponentLength = ByteArrays.getInt(rawData, curRelOffset + offset, 2);
      curRelOffset += 2;
      if (curRelOffset + rsaExponentLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get rsa_exponent. ")
          .append("The data is too short to build an TlsServerRsaParamsHeader (")
          .append(curRelOffset + rsaExponentLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (rsaExponentLength < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("rsa_exponent length must be more than 0 but is: ")
          .append(rsaExponentLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (rsaExponentLength > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("rsa_exponent length must be less than (1 << 16) but is: ")
          .append(rsaExponentLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.rsaExponent = ByteArrays.getSubArray(rawData, curRelOffset + offset, rsaExponentLength);

      this.signatureAlgorithm = TlsSignatureAlgorithm.ANONYMOUS; // TODO TLS session
    }

    private TlsServerRsaParamsHeader(Builder builder) {
      this.rsaModulus = ByteArrays.clone(builder.rsaModulus);
      this.rsaExponent = ByteArrays.clone(builder.rsaExponent);
      this.signatureAlgorithm = builder.signatureAlgorithm;
    }

    /**
     *
     * @return rsaModulus
     */
    public byte[] getRsaModulus() {
      return ByteArrays.clone(rsaModulus);
    }

    /**
     *
     * @return rsaExponent
     */
    public byte[] getRsaExponent() {
      return ByteArrays.clone(rsaExponent);
    }

    /**
     * @return signatureAlgorithm
     */
    public TlsSignatureAlgorithm getSignatureAlgorithm() {
      return signatureAlgorithm;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray((short)rsaModulus.length));
      rawFields.add(rsaModulus);
      rawFields.add(ByteArrays.toByteArray((short)rsaExponent.length));
      rawFields.add(rsaExponent);
      return rawFields;
    }

    @Override
    public int length() {
      return rsaModulus.length + rsaExponent.length + 4;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Server RSA Params Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  RSA Modulus: ")
        .append(ByteArrays.toHexString(rsaModulus, " "))
        .append(ls);
      sb.append("  RSA Exponent: ")
        .append(ByteArrays.toHexString(rsaExponent, " "))
        .append(ls);
      sb.append("  Signature Algorithm: ")
        .append(signatureAlgorithm)
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsServerRsaParamsHeader other = (TlsServerRsaParamsHeader)obj;
      return
           Arrays.equals(rsaModulus, other.rsaModulus)
        && Arrays.equals(rsaExponent, other.rsaExponent)
        && signatureAlgorithm.equals(other.signatureAlgorithm);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + Arrays.hashCode(rsaModulus);
      result = 31 * result + Arrays.hashCode(rsaExponent);
      result = 31 * result + signatureAlgorithm.hashCode();
      return result;
    }

  }

}
