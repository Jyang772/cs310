/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.packet.factory.PacketFactories;
import org.pcap4j.packet.namednumber.TlsSignatureAlgorithm;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsServerDhParamsPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 6801613481411527358L;

  private final TlsServerDhParamsHeader header;
  private final Packet payload;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsServerDhParamsPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsServerDhParamsPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsServerDhParamsPacket(rawData, offset, length);
  }

  private TlsServerDhParamsPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsServerDhParamsHeader(rawData, offset, length);

    int payloadLength = length - header.length();
    if (payloadLength != 0) { // payloadLength is positive.
      this.payload
        = PacketFactories.getFactory(Packet.class, TlsSignatureAlgorithm.class)
            .newInstance(
               rawData,
               offset + header.length(),
               payloadLength,
               header.getSignatureAlgorithm()
             );
    }
    else {
      this.payload = null;
    }
  }

  private TlsServerDhParamsPacket(Builder builder) {
    if (
         builder == null
      || builder.dhP == null
      || builder.dhG == null
      || builder.dhYs == null
      || builder.signatureAlgorithm == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.dhP: ").append(builder.dhP)
        .append(" builder.dhG: ").append(builder.dhG)
        .append(" builder.dhYs: ").append(builder.dhYs)
        .append(" builder.signatureAlgorithm: ").append(builder.signatureAlgorithm);;
      throw new NullPointerException(sb.toString());
    }

    this.payload = builder.payloadBuilder != null ? builder.payloadBuilder.build() : null;
    this.header = new TlsServerDhParamsHeader(builder);
  }

  @Override
  public TlsServerDhParamsHeader getHeader() {
    return header;
  }

  @Override
  public Packet getPayload() {
    return payload;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private byte[] dhP;
    private byte[] dhG;
    private byte[] dhYs;
    private TlsSignatureAlgorithm signatureAlgorithm;
    private Packet.Builder payloadBuilder;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsServerDhParamsPacket packet) {
      this.dhP = packet.header.dhP;
      this.dhG = packet.header.dhG;
      this.dhYs = packet.header.dhYs;
      this.signatureAlgorithm = packet.header.signatureAlgorithm;
      this.payloadBuilder = packet.payload != null ? packet.payload.getBuilder() : null;
    }

    /**
     *
     * @param dhP
     * @return this Builder object for method chaining.
     */
    public Builder dhP(byte[] dhP) {
      this.dhP = dhP;
      return this;
    }

    /**
     *
     * @param dhG
     * @return this Builder object for method chaining.
     */
    public Builder dhG(byte[] dhG) {
      this.dhG = dhG;
      return this;
    }

    /**
     *
     * @param dhYs
     * @return this Builder object for method chaining.
     */
    public Builder dhYs(byte[] dhYs) {
      this.dhYs = dhYs;
      return this;
    }

    /**
     *
     * @param signatureAlgorithm
     * @return this Builder object for method chaining.
     */
    public Builder signatureAlgorithm(TlsSignatureAlgorithm signatureAlgorithm) {
      this.signatureAlgorithm = signatureAlgorithm;
      return this;
    }

    @Override
    public Builder payloadBuilder(Packet.Builder payloadBuilder) {
      this.payloadBuilder = payloadBuilder;
      return this;
    }

    @Override
    public Packet.Builder getPayloadBuilder() {
      return payloadBuilder;
    }

    @Override
    public TlsServerDhParamsPacket build() {
      return new TlsServerDhParamsPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsServerDhParamsHeader extends AbstractHeader {

    /*
     * struct {
     *
     *    opaque dh_p<1..2^16-1>;
     *    opaque dh_g<1..2^16-1>;
     *    opaque dh_Ys<1..2^16-1>;
     *
     * } ServerRSAParams;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -7959197744839576765L;

    private static final int TLS_SERVER_DH_PARAMS_HEADER_MIN = 9;

    private final byte[] dhP;
    private final byte[] dhG;
    private final byte[] dhYs;
    private final TlsSignatureAlgorithm signatureAlgorithm; // pseudo field

    private TlsServerDhParamsHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_SERVER_DH_PARAMS_HEADER_MIN) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsServerDhParamsHeader (")
          .append(TLS_SERVER_DH_PARAMS_HEADER_MIN)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      int curRelOffset = 0;
      int dhPLength = ByteArrays.getInt(rawData, curRelOffset + offset, 2);
      curRelOffset += 2;
      if (curRelOffset + dhPLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get dh_p. ")
          .append("The data is too short to build an TlsServerDhParamsHeader (")
          .append(curRelOffset + dhPLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (dhPLength < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_p length must be more than 0 but is: ")
          .append(dhPLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (dhPLength > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_p length must be less than (1 << 16) but is: ")
          .append(dhPLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.dhP = ByteArrays.getSubArray(rawData, curRelOffset + offset, dhPLength);
      curRelOffset += dhPLength;

      if (curRelOffset + 2 > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get dhGLength. ")
          .append("The data is too short to build an TlsServerDhParamsHeader (")
          .append(curRelOffset + 2)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      int dhGLength = ByteArrays.getInt(rawData, curRelOffset + offset, 2);
      curRelOffset += 2;
      if (curRelOffset + dhGLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get dh_g. ")
          .append("The data is too short to build an TlsServerDhParamsHeader (")
          .append(curRelOffset + dhGLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (dhGLength < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_g length must be more than 0 but is: ")
          .append(dhGLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (dhGLength > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_g length must be less than (1 << 16) but is: ")
          .append(dhGLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.dhG = ByteArrays.getSubArray(rawData, curRelOffset + offset, dhGLength);
      curRelOffset += dhGLength;

      if (curRelOffset + 2 > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get dhYsLength. ")
          .append("The data is too short to build an TlsServerDhParamsHeader (")
          .append(curRelOffset + 2)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      int dhYsLength = ByteArrays.getInt(rawData, curRelOffset + offset, 2);
      curRelOffset += 2;
      if (curRelOffset + dhYsLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get dh_Ys. ")
          .append("The data is too short to build an TlsServerDhParamsHeader (")
          .append(curRelOffset + dhYsLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (dhYsLength < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_Ys length must be more than 0 but is: ")
          .append(dhYsLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (dhYsLength > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_Ys length must be less than (1 << 16) but is: ")
          .append(dhYsLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.dhYs = ByteArrays.getSubArray(rawData, curRelOffset + offset, dhYsLength);

      this.signatureAlgorithm = TlsSignatureAlgorithm.ANONYMOUS; // TODO TLS session
    }

    private TlsServerDhParamsHeader(Builder builder) {
      this.dhP = ByteArrays.clone(builder.dhP);
      this.dhG = ByteArrays.clone(builder.dhG);
      this.dhYs = ByteArrays.clone(builder.dhYs);
      this.signatureAlgorithm = builder.signatureAlgorithm;
    }

    /**
     *
     * @return dhP
     */
    public byte[] getDhP() {
      return ByteArrays.clone(dhP);
    }

    /**
     *
     * @return dhG
     */
    public byte[] getDhG() {
      return ByteArrays.clone(dhG);
    }

    /**
     *
     * @return dhYs
     */
    public byte[] getDhYs() {
      return ByteArrays.clone(dhYs);
    }

    /**
     * @return signatureAlgorithm
     */
    public TlsSignatureAlgorithm getSignatureAlgorithm() {
      return signatureAlgorithm;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray((short)dhP.length));
      rawFields.add(dhP);
      rawFields.add(ByteArrays.toByteArray((short)dhG.length));
      rawFields.add(dhG);
      rawFields.add(ByteArrays.toByteArray((short)dhYs.length));
      rawFields.add(dhYs);
      return rawFields;
    }

    @Override
    public int length() {
      return dhP.length + dhG.length + dhYs.length + 6;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Server DH Params Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  DH p: ")
        .append(ByteArrays.toHexString(dhP, " "))
        .append(ls);
      sb.append("  DH g: ")
        .append(ByteArrays.toHexString(dhG, " "))
        .append(ls);
      sb.append("  DH Ys: ")
        .append(ByteArrays.toHexString(dhYs, " "))
        .append(ls);
      sb.append("  Signature Algorithm: ")
        .append(signatureAlgorithm)
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsServerDhParamsHeader other = (TlsServerDhParamsHeader)obj;
      return
           Arrays.equals(dhP, other.dhP)
        && Arrays.equals(dhG, other.dhG)
        && Arrays.equals(dhYs, other.dhYs)
        && signatureAlgorithm.equals(other.signatureAlgorithm);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + Arrays.hashCode(dhP);
      result = 31 * result + Arrays.hashCode(dhG);
      result = 31 * result + Arrays.hashCode(dhYs);
      result = 31 * result + signatureAlgorithm.hashCode();
      return result;
    }

  }

}
