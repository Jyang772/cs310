/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import static org.pcap4j.util.ByteArrays.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.packet.namednumber.TlsCipherSuite;
import org.pcap4j.packet.namednumber.TlsCompressionMethod;
import org.pcap4j.packet.namednumber.TlsProtocolVersion;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsServerHelloPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 5718924304991033576L;

  private final TlsServerHelloHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsServerHelloPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsServerHelloPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsServerHelloPacket(rawData, offset, length);
  }

  private TlsServerHelloPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsServerHelloHeader(rawData, offset, length);
  }

  private TlsServerHelloPacket(Builder builder) {

    if (
         builder == null
      || builder.serverVersion == null
      || builder.randomBytes == null
      || builder.sessionId == null
      || builder.cipherSuite == null
      || builder.compressionMethod == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.serverVersion: ").append(builder.serverVersion)
        .append(" builder.randomBytes: ").append(builder.randomBytes)
        .append(" builder.sessionId: ").append(builder.sessionId)
        .append(" builder.cipherSuites: ").append(builder.cipherSuite)
        .append(" builder.compressionMethods: ").append(builder.compressionMethod);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsServerHelloHeader(builder);
  }

  @Override
  public TlsServerHelloHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private TlsProtocolVersion serverVersion;
    private int gmtUnixTime;
    private byte[] randomBytes;
    private byte[] sessionId;
    private TlsCipherSuite cipherSuite;
    private TlsCompressionMethod compressionMethod;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsServerHelloPacket packet) {
      this.serverVersion = packet.header.serverVersion;
      this.gmtUnixTime = packet.header.gmtUnixTime;
      this.randomBytes = packet.header.randomBytes;
      this.sessionId = packet.header.sessionId;
      this.cipherSuite = packet.header.cipherSuite;
      this.compressionMethod = packet.header.compressionMethod;
    }

    /**
     *
     * @param serverVersion
     * @return this Builder object for method chaining.
     */
    public Builder serverVersion(TlsProtocolVersion serverVersion) {
      this.serverVersion = serverVersion;
      return this;
    }

    /**
     *
     * @param gmtUnixTime
     * @return this Builder object for method chaining.
     */
    public Builder gmtUnixTime(int gmtUnixTime) {
      this.gmtUnixTime = gmtUnixTime;
      return this;
    }

    /**
     *
     * @param randomBytes
     * @return this Builder object for method chaining.
     */
    public Builder randomBytes(byte[] randomBytes) {
      this.randomBytes = randomBytes;
      return this;
    }

    /**
     *
     * @param sessionId
     * @return this Builder object for method chaining.
     */
    public Builder sessionId(byte[] sessionId) {
      this.sessionId = sessionId;
      return this;
    }

    /**
     *
     * @param cipherSuite
     * @return this Builder object for method chaining.
     */
    public Builder cipherSuite(TlsCipherSuite cipherSuite) {
      this.cipherSuite = cipherSuite;
      return this;
    }

    /**
     *
     * @param compressionMethod
     * @return this Builder object for method chaining.
     */
    public Builder compressionMethod(TlsCompressionMethod compressionMethod) {
      this.compressionMethod = compressionMethod;
      return this;
    }

    @Override
    public TlsServerHelloPacket build() {
      return new TlsServerHelloPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsServerHelloHeader extends AbstractHeader {

    /*
     * struct {
     *
     *     uint32 gmt_unix_time;
     *     opaque random_bytes[28];
     *
     * } Random;
     * opaque SessionID<0..32>;
     * uint8 CipherSuite[2];
     * enum { null(0), (255) } CompressionMethod;
     * struct {
     *     ProtocolVersion server_version;
     *     Random random;
     *     SessionID session_id;
     *     CipherSuite cipher_suite;
     *     CompressionMethod compression_method;
     * } ServerHello;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -8350226930048803549L;

    private static final int SERVER_VERSION_OFFSET
      = 0;
    private static final int SERVER_VERSION_SIZE
      = SHORT_SIZE_IN_BYTES;
    private static final int GMT_UNIX_TIME_OFFSET
      = SERVER_VERSION_OFFSET + SERVER_VERSION_SIZE;
    private static final int GMT_UNIX_TIME_SIZE
      = INT_SIZE_IN_BYTES;
    private static final int RANDOM_BYTES_OFFSET
      = GMT_UNIX_TIME_OFFSET + GMT_UNIX_TIME_SIZE;
    private static final int RANDOM_BYTES_LENGTH
      = 28;
    private static final int SESSION_ID_OFFSET
      = RANDOM_BYTES_OFFSET + RANDOM_BYTES_LENGTH;

    private final TlsProtocolVersion serverVersion;
    private final int gmtUnixTime;
    private final byte[] randomBytes;
    private final byte[] sessionId;
    private final TlsCipherSuite cipherSuite;
    private final TlsCompressionMethod compressionMethod;

    private TlsServerHelloHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < SESSION_ID_OFFSET + 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsServerHelloHeader (")
          .append(SESSION_ID_OFFSET + 1)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.serverVersion = TlsProtocolVersion.getInstance(ByteArrays.getShort(rawData, offset));
      this.gmtUnixTime
        = ByteArrays.getInt(rawData, GMT_UNIX_TIME_OFFSET + offset);
      this.randomBytes
        = ByteArrays.getSubArray(rawData, RANDOM_BYTES_OFFSET + offset, RANDOM_BYTES_LENGTH);

      int curRelOffset = SESSION_ID_OFFSET;
      int sessionIdLength = 0xFF & rawData[curRelOffset + offset];
      curRelOffset++;
      if (curRelOffset + sessionIdLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get sessionId. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + sessionIdLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (sessionIdLength == 0) {
        this.sessionId = new byte[0];
      }
      else if (sessionIdLength > 32) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("sessionId length must be less than 33 but is: ")
          .append(sessionIdLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      else {
        this.sessionId
          = ByteArrays.getSubArray(rawData, curRelOffset + offset, sessionIdLength);
      }
      curRelOffset += sessionId.length;

      if (curRelOffset + SHORT_SIZE_IN_BYTES > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get cipher_suite. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + SHORT_SIZE_IN_BYTES)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.cipherSuite = TlsCipherSuite.getInstance(
                           ByteArrays.getShort(rawData, curRelOffset + offset)
                         );
      curRelOffset += SHORT_SIZE_IN_BYTES;

      if (curRelOffset + BYTE_SIZE_IN_BYTES > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get compressionMethod. ")
          .append("The data is too short to build an TlsServerHelloHeader (")
          .append(curRelOffset + BYTE_SIZE_IN_BYTES)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.compressionMethod = TlsCompressionMethod.getInstance(
                                 ByteArrays.getByte(rawData, curRelOffset + offset)
                               );
    }

    private TlsServerHelloHeader(Builder builder) {
      if (builder.sessionId.length > 32) {
        throw new IllegalArgumentException(
                "sessionId length must be less than 33 but is: " + builder.sessionId.length
              );
      }

      this.serverVersion = builder.serverVersion;
      this.gmtUnixTime = builder.gmtUnixTime;
      this.randomBytes = ByteArrays.clone(builder.randomBytes);
      this.sessionId = ByteArrays.clone(builder.sessionId);
      this.cipherSuite = builder.cipherSuite;
      this.compressionMethod = builder.compressionMethod;
    }

    /**
     * @return serverVersion
     */
    public TlsProtocolVersion getServerVersion() {
      return serverVersion;
    }

    /**
     * @return gmtUnixTime
     */
    public int getGmtUnixTime() {
      return gmtUnixTime;
    }

    /**
     * @return gmtUnixTime
     */
    public long getGmtUnixTimeAsLong() {
      return 0xFFFFFFFFL & gmtUnixTime;
    }

    /**
     * @return randomBytes
     */
    public byte[] getRandomBytes() {
      return ByteArrays.clone(randomBytes);
    }

    /**
     * @return sessionId
     */
    public byte[] getSessionId() {
      return ByteArrays.clone(sessionId);
    }

    /**
     * @return cipherSuite
     */
    public TlsCipherSuite getCipherSuite() {
      return cipherSuite;
    }

    /**
     * @return compressionMethod
     */
    public TlsCompressionMethod getCompressionMethod() {
      return compressionMethod;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();

      rawFields.add(ByteArrays.toByteArray(serverVersion.value()));
      rawFields.add(ByteArrays.toByteArray(gmtUnixTime));
      rawFields.add(randomBytes);
      rawFields.add(ByteArrays.toByteArray((byte)sessionId.length));
      rawFields.add(sessionId);
      rawFields.add(ByteArrays.toByteArray(cipherSuite.value()));
      rawFields.add(ByteArrays.toByteArray(compressionMethod.value()));

      return rawFields;
    }

    @Override
    protected int calcLength() {
      return SESSION_ID_OFFSET + 1 + sessionId.length + 3;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Server Hello Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Server Version: ")
        .append(serverVersion)
        .append(ls);
      sb.append("  GMT UNIX Time: ")
        .append(getGmtUnixTimeAsLong())
        .append(ls);
      sb.append("  Random Bytes: ")
        .append(ByteArrays.toHexString(randomBytes, " "))
        .append(ls);
      sb.append("  Session ID: ")
        .append(ByteArrays.toHexString(sessionId, " "))
        .append(ls);
      sb.append("  Cipher Suite: ")
        .append(cipherSuite)
        .append(ls);
      sb.append("  Compression Method: ")
        .append(compressionMethod)
        .append(ls);

      return sb.toString();
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + serverVersion.hashCode();
      result = 31 * result + gmtUnixTime;
      result = 31 * result + Arrays.hashCode(randomBytes);
      result = 31 * result + Arrays.hashCode(sessionId);
      result = 31 * result + cipherSuite.hashCode();
      result = 31 * result + compressionMethod.hashCode();
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) { return true; }
      if (getClass() != obj.getClass()) { return false; }

      TlsServerHelloHeader other = (TlsServerHelloHeader)obj;
      return
           gmtUnixTime == other.gmtUnixTime
        && Arrays.equals(sessionId, other.sessionId)
        && Arrays.equals(randomBytes, other.randomBytes)
        && cipherSuite.equals(other.cipherSuite)
        && compressionMethod.equals(other.compressionMethod)
        && serverVersion.equals(other.serverVersion);
    }

  }

}
