/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsClientCertificatePacket extends TlsAbstractCertificatePacket {

  /**
   *
   */
  private static final long serialVersionUID = -6427571754820252924L;

  private final TlsClientCertificateHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsClientCertificatePacket object.
   * @throws IllegalRawDataException
   */
  public static TlsClientCertificatePacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsClientCertificatePacket(rawData, offset, length);
  }

  private TlsClientCertificatePacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsClientCertificateHeader(rawData, offset, length);
  }

  private TlsClientCertificatePacket(Builder builder) {
    super(builder);
    this.header = new TlsClientCertificateHeader(builder);
  }

  @Override
  public TlsClientCertificateHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends TlsAbstractCertificatePacket.Builder {

    /**
     *
     */
    public Builder() {}

    private Builder(TlsClientCertificatePacket packet) {
      super(packet);
    }

    @Override
    public Builder certificateList(List<byte[]> certificateList) {
      super.certificateList(certificateList);
      return this;
    }

    @Override
    public TlsClientCertificatePacket build() {
      return new TlsClientCertificatePacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsClientCertificateHeader extends TlsAbstractCertificateHeader {

    /*
     * opaque ASN.1Cert<1..2^24-1>;
     * struct {
     *
     *     ASN.1Cert certificate_list<0..2^24-1>;
     *
     * } Certificate;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -7996958428663993852L;

    private TlsClientCertificateHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      super(rawData, offset, length);
    }

    private TlsClientCertificateHeader(Builder builder) {
      super(builder);
    }

    @Override
    protected String getHeaderName() {
      return "TLS Client Certificate Header";
    }

  }

}
