/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import static org.pcap4j.util.ByteArrays.*;
import java.util.ArrayList;
import java.util.List;
import org.pcap4j.packet.namednumber.TlsChangeCipherSpecType;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsChangeCipherSpecPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 4443047604914834778L;

  private final TlsChangeCipherSpecHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsChangeCipherSpecPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsChangeCipherSpecPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsChangeCipherSpecPacket(rawData, offset, length);
  }

  private TlsChangeCipherSpecPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsChangeCipherSpecHeader(rawData, offset, length);
  }

  private TlsChangeCipherSpecPacket(Builder builder) {
    if (
         builder == null
      || builder.type == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.type: ").append(builder.type);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsChangeCipherSpecHeader(builder);
  }

  @Override
  public TlsChangeCipherSpecHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final
  class Builder extends AbstractBuilder {

    private TlsChangeCipherSpecType type;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsChangeCipherSpecPacket packet) {
      this.type = packet.header.type;
    }

    /**
     *
     * @param type
     * @return this Builder object for method chaining.
     */
    public Builder type(TlsChangeCipherSpecType type) {
      this.type = type;
      return this;
    }

    @Override
    public TlsChangeCipherSpecPacket build() {
      return new TlsChangeCipherSpecPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsChangeCipherSpecHeader extends AbstractHeader {

    /*
     * struct {
     *
     *   enum { change_cipher_spec(1), (255) } type;
     *
     * } ChangeCipherSpec;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = 3621791364440583445L;

    private static final int TYPE_OFFSET
      = 0;
    private static final int TYPE_SIZE
      = BYTE_SIZE_IN_BYTES;
    private static final int TLS_CHANGE_CIPHER_SPEC_HEADER_SIZE
      = TYPE_OFFSET + TYPE_SIZE;

    private final TlsChangeCipherSpecType type;

    private TlsChangeCipherSpecHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_CHANGE_CIPHER_SPEC_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsChangeCipherSpecHeader (")
          .append(TLS_CHANGE_CIPHER_SPEC_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.type
        = TlsChangeCipherSpecType
            .getInstance(ByteArrays.getByte(rawData, TYPE_OFFSET + offset));
    }

    private TlsChangeCipherSpecHeader(Builder builder) {
      this.type = builder.type;
    }

    /**
     *
     * @return type
     */
    public TlsChangeCipherSpecType getType() {
      return type;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray(type.value()));
      return rawFields;
    }

    @Override
    public int length() {
      return TLS_CHANGE_CIPHER_SPEC_HEADER_SIZE;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Change Cipher Spec Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Type: ")
        .append(type)
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsChangeCipherSpecHeader other = (TlsChangeCipherSpecHeader)obj;
      return type.equals(other.type);
    }

    @Override
    protected int calcHashCode() {
      return type.hashCode();
    }

  }

}
