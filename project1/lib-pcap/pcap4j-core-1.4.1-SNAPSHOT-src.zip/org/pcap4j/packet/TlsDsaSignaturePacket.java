/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsDsaSignaturePacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 8192936376874497844L;

  private final TlsDsaSignatureHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsDsaSignaturePacket object.
   * @throws IllegalRawDataException
   */
  public static TlsDsaSignaturePacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsDsaSignaturePacket(rawData, offset, length);
  }

  private TlsDsaSignaturePacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsDsaSignatureHeader(rawData, offset, length);
  }

  private TlsDsaSignaturePacket(Builder builder) {
    if (
         builder == null
      || builder.shaHash == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.shaHash: ").append(builder.shaHash);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsDsaSignatureHeader(builder);
  }

  @Override
  public TlsDsaSignatureHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private byte[] shaHash;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsDsaSignaturePacket packet) {
      this.shaHash = packet.header.shaHash;
    }

    /**
     *
     * @param shaHash
     * @return this Builder object for method chaining.
     */
    public Builder shaHash(byte[] shaHash) {
      this.shaHash = shaHash;
      return this;
    }

    @Override
    public TlsDsaSignaturePacket build() {
      return new TlsDsaSignaturePacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsDsaSignatureHeader extends AbstractHeader {

    /*
     *  digitally-signed struct {
     *
     *     opaque sha_hash[20];
     *
     * };
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = 674322224739289698L;

    private static final int SHA_HASH_OFFSET
      = 0;
    private static final int SHA_HASH__SIZE
      = 20;
    private static final int TLS_DSA_SIGNATURE_HEADER_SIZE
      = SHA_HASH_OFFSET + SHA_HASH__SIZE;

    private final byte[] shaHash;

    private TlsDsaSignatureHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_DSA_SIGNATURE_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsDsaSignatureHeader (")
          .append(TLS_DSA_SIGNATURE_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.shaHash
        = ByteArrays.getSubArray(rawData, SHA_HASH_OFFSET + offset, SHA_HASH__SIZE);
    }

    private TlsDsaSignatureHeader(Builder builder) {
      this.shaHash = ByteArrays.clone(builder.shaHash);
    }

    /**
     *
     * @return shaHash
     */
    public byte[] getShaHash() {
      return ByteArrays.clone(shaHash);
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(shaHash);
      return rawFields;
    }

    @Override
    public int length() {
      return TLS_DSA_SIGNATURE_HEADER_SIZE;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS DSA Signature Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  SHA Hash: ")
        .append(ByteArrays.toHexString(shaHash, " "))
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsDsaSignatureHeader other = (TlsDsaSignatureHeader)obj;
      return Arrays.equals(shaHash, other.shaHash);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + Arrays.hashCode(shaHash);
      return result;
    }

  }

}
