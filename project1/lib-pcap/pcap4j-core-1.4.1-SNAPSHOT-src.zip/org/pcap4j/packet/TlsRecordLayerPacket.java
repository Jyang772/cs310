/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import static org.pcap4j.util.ByteArrays.*;
import java.util.ArrayList;
import java.util.List;
import org.pcap4j.packet.factory.PacketFactories;
import org.pcap4j.packet.namednumber.TlsContentType;
import org.pcap4j.packet.namednumber.TlsProtocolVersion;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsRecordLayerPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 2412297214569607778L;

  private final TlsRecordLayerHeader header;
  private final Packet payload;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsRecordLayerPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsRecordLayerPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsRecordLayerPacket(rawData, offset, length);
  }

  private TlsRecordLayerPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsRecordLayerHeader(rawData, offset, length);

    int payloadLength = header.getLengthAsInt();
    if (payloadLength > length - header.length()) {
      payloadLength = length - header.length();
    }

    if (payloadLength > 0) {
      this.payload
        = PacketFactories.getFactory(Packet.class, TlsContentType.class)
            .newInstance(rawData, offset + header.length(), payloadLength, header.getType());
    }
    else {
      this.payload = null;
    }
  }

  private TlsRecordLayerPacket(Builder builder) {
    if (
         builder == null
      || builder.type == null
      || builder.version == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.type: ").append(builder.type)
        .append(" builder.version: ").append(builder.version);
      throw new NullPointerException(sb.toString());
    }

    this.payload = builder.payloadBuilder != null ? builder.payloadBuilder.build() : null;
    if (payload != null) {
      if (payload.length() > 65535) {
        throw new IllegalArgumentException(
                    "payload must be shorter than 65536 but it is: " + payload.length()
                  );
      }
      this.header = new TlsRecordLayerHeader(builder, payload.length());
    }
    else {
      this.header = new TlsRecordLayerHeader(builder, 0);
    }
  }

  @Override
  public TlsRecordLayerHeader getHeader() {
    return header;
  }

  @Override
  public Packet getPayload() {
    return payload;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final
  class Builder extends AbstractBuilder
  implements LengthBuilder<TlsRecordLayerPacket> {

    private TlsContentType type;
    private TlsProtocolVersion version;
    private short length;
    private Packet.Builder payloadBuilder;
    private boolean correctLengthAtBuild;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsRecordLayerPacket packet) {
      this.type = packet.header.type;
      this.version = packet.header.version;
      this.length = packet.header.length;
      this.payloadBuilder = packet.payload != null ? packet.payload.getBuilder() : null;
    }

    /**
     *
     * @param type
     * @return this Builder object for method chaining.
     */
    public Builder type(TlsContentType type) {
      this.type = type;
      return this;
    }

    /**
     *
     * @param version
     * @return this Builder object for method chaining.
     */
    public Builder version(TlsProtocolVersion version) {
      this.version = version;
      return this;
    }

    /**
     *
     * @param length
     * @return this Builder object for method chaining.
     */
    public Builder length(short length) {
      this.length = length;
      return this;
    }

    @Override
    public Builder payloadBuilder(Packet.Builder payloadBuilder) {
      this.payloadBuilder = payloadBuilder;
      return this;
    }

    @Override
    public Packet.Builder getPayloadBuilder() {
      return payloadBuilder;
    }

    @Override
    public Builder correctLengthAtBuild(boolean correctLengthAtBuild) {
      this.correctLengthAtBuild = correctLengthAtBuild;
      return this;
    }

    @Override
    public TlsRecordLayerPacket build() {
      return new TlsRecordLayerPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsRecordLayerHeader extends AbstractHeader {

    /*
     *  struct {
     *
     *      uint8 major, minor;
     *
     *  } ProtocolVersion;
     *  enum {
     *
     *      change_cipher_spec(20), alert(21), handshake(22),
     *      application_data(23), (255)
     *
     *  } ContentType;
     *  struct {
     *
     *      ContentType type;
     *      ProtocolVersion version;
     *      uint16 length;
     *      opaque fragment[TLSPlaintext.length];
     *
     *  } TLSPlaintext;
     */

    /**
     *
     */
    private static final long serialVersionUID = 7749429365271318906L;

    private static final int TYPE_OFFSET
      = 0;
    private static final int TYPE_SIZE
      = BYTE_SIZE_IN_BYTES;
    private static final int VERSION_OFFSET
      = TYPE_OFFSET + TYPE_SIZE;
    private static final int VERSION_SIZE
      = SHORT_SIZE_IN_BYTES;
    private static final int LENGTH_OFFSET
      = VERSION_OFFSET + VERSION_SIZE;
    private static final int LENGTH_SIZE
      = SHORT_SIZE_IN_BYTES;
    private static final int TLS_RECORD_LAYER_HEADER_SIZE
      = LENGTH_OFFSET + LENGTH_SIZE;

    private final TlsContentType type;
    private final TlsProtocolVersion version;
    private final short length;

    private TlsRecordLayerHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_RECORD_LAYER_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsRecordLayerHeader (")
          .append(TLS_RECORD_LAYER_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.type
        = TlsContentType
            .getInstance(ByteArrays.getByte(rawData, TYPE_OFFSET + offset));
      this.version
        = TlsProtocolVersion
            .getInstance(ByteArrays.getShort(rawData, VERSION_OFFSET + offset));
      this.length = ByteArrays.getShort(rawData, LENGTH_OFFSET + offset);
    }

    private TlsRecordLayerHeader(Builder builder, int payloadLength) {
      this.type = builder.type;
      this.version = builder.version;

      if (builder.correctLengthAtBuild) {
        this.length = (short)payloadLength;
      }
      else {
        this.length = builder.length;
      }
    }

    /**
     *
     * @return type
     */
    public TlsContentType getType() {
      return type;
    }

    /**
     *
     * @return version
     */
    public TlsProtocolVersion getVersion() {
      return version;
    }

    /**
     *
     * @return length
     */
    public short getLength() {
      return length;
    }

    /**
     *
     * @return length
     */
    public int getLengthAsInt() {
      return length & 0xFFFF;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray(type.value()));
      rawFields.add(ByteArrays.toByteArray(version.value()));
      rawFields.add(ByteArrays.toByteArray(length));
      return rawFields;
    }

    @Override
    public int length() {
      return TLS_RECORD_LAYER_HEADER_SIZE;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Record Layer Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Type: ")
        .append(type)
        .append(ls);
      sb.append("  Version: ")
        .append(version)
        .append(ls);
      sb.append("  Length: ")
        .append(length)
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsRecordLayerHeader other = (TlsRecordLayerHeader)obj;
      return
           length == other.length
        && type.equals(other.type)
        && version.equals(other.version);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + type.hashCode();
      result = 31 * result + version.hashCode();
      result = 31 * result + length;
      return result;
    }

  }

}
