/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import static org.pcap4j.util.ByteArrays.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.pcap4j.packet.namednumber.TlsClientCertificateType;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsCertificateRequestPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 6489493569299375942L;

  private final TlsCertificateRequestHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsCertificateRequestPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsCertificateRequestPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsCertificateRequestPacket(rawData, offset, length);
  }

  private TlsCertificateRequestPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsCertificateRequestHeader(rawData, offset, length);
  }

  private TlsCertificateRequestPacket(Builder builder) {
    if (
         builder == null
      || builder.certificateTypes == null
      || builder.certificateAuthorities == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.certificateTypes: ").append(builder.certificateTypes)
        .append(" builder.certificateAuthorities: ").append(builder.certificateAuthorities);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsCertificateRequestHeader(builder);
  }

  @Override
  public TlsCertificateRequestHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private List<TlsClientCertificateType> certificateTypes;
    private List<byte[]> certificateAuthorities;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsCertificateRequestPacket packet) {
      this.certificateTypes = packet.header.certificateTypes;
      this.certificateAuthorities = packet.header.certificateAuthorities;
    }

    /**
     *
     * @param certificateTypes
     * @return this Builder object for method chaining.
     */
    public Builder certificateTypes(List<TlsClientCertificateType> certificateTypes) {
      this.certificateTypes = certificateTypes;
      return this;
    }

    /**
     *
     * @param certificateAuthorities
     * @return this Builder object for method chaining.
     */
    public Builder certificateAuthorities(List<byte[]> certificateAuthorities) {
      this.certificateAuthorities = certificateAuthorities;
      return this;
    }

    @Override
    public TlsCertificateRequestPacket build() {
      return new TlsCertificateRequestPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsCertificateRequestHeader extends AbstractHeader {

    /*
     * enum {
     *
     *     rsa_sign(1), dss_sign(2), rsa_fixed_dh(3), dss_fixed_dh(4),
     *     (255)
     *
     * } ClientCertificateType;
     * opaque DistinguishedName<1..2^16-1>;
     * struct {
     *
     *     ClientCertificateType certificate_types<1..2^8-1>;
     *     DistinguishedName certificate_authorities<3..2^16-1>;
     *
     * } CertificateRequest;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -975158300625203610L;

    private static final int TLS_CERTIFICATE_REQUEST_HEADER_MIN = 7;

    private final List<TlsClientCertificateType> certificateTypes
      = new ArrayList<TlsClientCertificateType>();
    private final List<byte[]> certificateAuthorities
      = new ArrayList<byte[]>();

    private TlsCertificateRequestHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_CERTIFICATE_REQUEST_HEADER_MIN) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsCertificateRequestHeader (")
          .append(TLS_CERTIFICATE_REQUEST_HEADER_MIN)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      int curRelOffset = 0;
      int certificateTypesLength = ByteArrays.getInt(rawData, offset, 1);
      curRelOffset += 1;
      if (curRelOffset + certificateTypesLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get certificate_types. ")
          .append("The data is too short to build an TlsCertificateRequestHeader (")
          .append(curRelOffset + certificateTypesLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (certificateTypesLength < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("certificate_types length must be more than 0 but is: ")
          .append(certificateTypesLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (certificateTypesLength > (1 << 8) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("certificate_list length must be less than (1 << 8) but is: ")
          .append(certificateTypesLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      for (int i = 0; i < certificateTypesLength; i ++) {
        certificateTypes.add(
          TlsClientCertificateType.getInstance(
            rawData[curRelOffset + i + offset]
          )
        );
      }
      curRelOffset += certificateTypes.size();

      if (curRelOffset + SHORT_SIZE_IN_BYTES > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get certificateAuthoritiesLength. ")
          .append("The data is too short to build an TlsCertificateRequestHeader (")
          .append(curRelOffset + SHORT_SIZE_IN_BYTES)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      int certificateAuthoritiesLength = ByteArrays.getInt(rawData, offset, 2);
      curRelOffset += 2;
      if (curRelOffset + certificateAuthoritiesLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get certificate_authorities. ")
          .append("The data is too short to build an TlsCertificateRequestHeader (")
          .append(curRelOffset + certificateAuthoritiesLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (certificateAuthoritiesLength < 3) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("certificate_authorities length must be more than 2 but is: ")
          .append(certificateAuthoritiesLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (certificateAuthoritiesLength > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("certificate_authorities length must be less than (1 << 16) but is: ")
          .append(certificateAuthoritiesLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      for (int processedBytes = 0; processedBytes < certificateAuthoritiesLength;) {
        if (processedBytes + 3 > certificateAuthoritiesLength) {
          StringBuilder sb = new StringBuilder(80);
          sb.append("Can't get dnLength. certificateAuthoritiesLength: ")
            .append(certificateAuthoritiesLength)
            .append(", processedBytes: ")
            .append(processedBytes)
            .append(", data: ")
            .append(ByteArrays.toHexString(rawData, " "))
            .append(", offset: ")
            .append(offset)
            .append(", length: ")
            .append(length);
          throw new IllegalRawDataException(sb.toString());
        }
        int caLength
          = ByteArrays.getInt(rawData, curRelOffset + processedBytes + offset, 2);
        processedBytes += 2;
        if (processedBytes + caLength > certificateAuthoritiesLength) {
          StringBuilder sb = new StringBuilder(80);
          sb.append("Can't get a certificate_authority. ")
            .append("The data is too short to build an TlsCertificateRequestHeader (")
            .append(curRelOffset + processedBytes + caLength)
            .append(" bytes). data: ")
            .append(ByteArrays.toHexString(rawData, " "))
            .append(", offset: ")
            .append(offset)
            .append(", length: ")
            .append(length);
          throw new IllegalRawDataException(sb.toString());
        }
//        if (caLength > (1 << 16) - 1) {
//          throw new AssertionError();
//        }

        byte[] distinguishedName
          = ByteArrays.getSubArray(
              rawData, curRelOffset + processedBytes + offset, caLength
            );
        certificateAuthorities.add(distinguishedName);
        processedBytes += distinguishedName.length;
      }
    }

    private TlsCertificateRequestHeader(Builder builder) {
      if (builder.certificateTypes.size() > (1 << 8) - 1) {
        throw new IllegalArgumentException(
                "certificateTypes length must be less than (1 << 8) but is: "
                  + certificateTypes.size()
              );
      }

      int total = 0;
      for (byte[] ca: builder.certificateAuthorities) {
        if (ca.length > (1 << 16) - 1) {
          throw new IllegalArgumentException(
                  "certificate length must be less than (1 << 16) but is: "
                    + ca.length
                );
        }
        this.certificateAuthorities.add(ByteArrays.clone(ca));

        total += ca.length;
        if (total > (1 << 16) - 1) {
          throw new IllegalArgumentException(
                  "certificate_authorities length must be less than (1 << 16)."
                );
        }
      }
    }

    /**
     *
     * @return certificateTypes
     */
    public List<TlsClientCertificateType> getCertificateTypes() {
      return new ArrayList<TlsClientCertificateType>(certificateTypes);
    }

    /**
     *
     * @return certificateAuthorities
     */
    public List<byte[]> getCertificateAuthorities() {
      List<byte[]> list = new ArrayList<byte[]>();
      for (byte[] ca: certificateAuthorities) {
        list.add(ByteArrays.clone(ca));
      }
      return list;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new LinkedList<byte[]>();

      for (TlsClientCertificateType ct: certificateTypes) {
        rawFields.add(ByteArrays.toByteArray(ct.value()));
      }
      rawFields.add(0, ByteArrays.toByteArray(certificateTypes.size(), 1));

      int offset = rawFields.size();
      int total = 0;
      for (byte[] ca: certificateAuthorities) {
        rawFields.add(ByteArrays.toByteArray(ca.length, 2));
        rawFields.add(ca);
        total += 2 + ca.length;
      }
      rawFields.add(offset, ByteArrays.toByteArray(total, 2));

      return rawFields;
    }

    @Override
    public int length() {
      int len = 1 + certificateTypes.size();
      len += 2;
      for (byte[] ca: certificateAuthorities) {
        len += 2 + ca.length;
      }
      return len;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Certificate Request Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Certificate Types: ")
        .append(ls);
      for (TlsClientCertificateType ct: certificateTypes) {
        sb.append("    ")
          .append(ct)
          .append(ls);
      }
      sb.append("  Certificate Authorities: ")
        .append(ls);
      for (byte[] ca: certificateAuthorities) {
        sb.append("    ")
          .append(ByteArrays.toHexString(ca, " "))
          .append(ls);
      }

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsCertificateRequestHeader other = (TlsCertificateRequestHeader)obj;
      if (!certificateTypes.equals(other.certificateTypes)) {
        return false;
      }

      if (certificateAuthorities.size() != other.certificateAuthorities.size()) {
        return false;
      }

      Iterator<byte[]> it = other.certificateAuthorities.iterator();
      for (byte[] ca: certificateAuthorities) {
        byte[] oca = it.next();
        if (!Arrays.equals(ca, oca)) {
          return false;
        }
      }

      return true;
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + certificateTypes.hashCode();
      for (byte[] ca: certificateAuthorities) {
        result = 31 * result + Arrays.hashCode(ca);
      }
      return result;
    }

  }

}
