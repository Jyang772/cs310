/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.List;
import org.pcap4j.packet.factory.PacketFactories;
import org.pcap4j.packet.namednumber.HttpStatusCode;
import org.pcap4j.packet.namednumber.NotApplicable;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.2.1
 */
public final class HttpPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = -7745545445348758353L;

  private final HttpHeader header;
  private final Packet payload;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new HttpPacket object.
   * @throws IllegalRawDataException
   */
  public static HttpPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new HttpPacket(rawData, offset, length);
  }

  private HttpPacket(byte[] rawData, int offset, int length) throws IllegalRawDataException {
    this.header = new HttpHeader(rawData, offset, length);

    int payloadLength = length - header.length();
    if (payloadLength > 0) {
      this.payload
        = PacketFactories.getFactory(Packet.class, NotApplicable.class)
            .newInstance(rawData, offset + header.length(), payloadLength, NotApplicable.UNKNOWN);
    }
    else {
      this.payload = null;
    }
  }

  private HttpPacket(Builder builder) {
    if (
         builder == null
      || builder.version == null
      || builder.statusCode == null
      || builder.reasonPhrase == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.version: ").append(builder.version)
        .append(" builder.statusCode: ").append(builder.statusCode)
        .append(" builder.reasonPhrase: ").append(builder.reasonPhrase);
      throw new NullPointerException(sb.toString());
    }

    this.payload = builder.payloadBuilder != null ? builder.payloadBuilder.build() : null;
    this.header = new HttpHeader(builder);
  }

  @Override
  public HttpHeader getHeader() {
    return header;
  }

  @Override
  public Packet getPayload() {
    return payload;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.2.1
   */
  public static final
  class Builder extends AbstractBuilder {

    private HttpVersion version;
    private HttpStatusCode statusCode;
    private String reasonPhrase;
    private Packet.Builder payloadBuilder;

    /**
     *
     */
    public Builder() {}

    private Builder(HttpPacket packet) {
      this.version = packet.header.version;
      this.statusCode = packet.header.statusCode;
      this.reasonPhrase = packet.header.reasonPhrase;
      this.payloadBuilder = packet.payload != null ? packet.payload.getBuilder() : null;
    }

    /**
     *
     * @param version
     * @return this Builder object for method chaining.
     */
    public Builder version(HttpVersion version) {
      this.version = version;
      return this;
    }

    /**
     *
     * @param statusCode
     * @return this Builder object for method chaining.
     */
    public Builder statusCode(HttpStatusCode statusCode) {
      this.statusCode = statusCode;
      return this;
    }

    /**
     *
     * @param reasonPhrase
     * @return this Builder object for method chaining.
     */
    public Builder reasonPhrase(String reasonPhrase) {
      this.reasonPhrase = reasonPhrase;
      return this;
    }

    @Override
    public Builder payloadBuilder(Packet.Builder payloadBuilder) {
      this.payloadBuilder = payloadBuilder;
      return this;
    }

    @Override
    public Packet.Builder getPayloadBuilder() {
      return payloadBuilder;
    }

    @Override
    public HttpPacket build() {
      return new HttpPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.2.1
   */
  public static final class HttpHeader extends AbstractHeader {

    /*
     * ftp://www.ietf.org/rfc/rfc2616.txt
     *
     * Response      = Status-Line               ; Section 6.1
     *                 *(( general-header        ; Section 4.5
     *                  | response-header        ; Section 6.2
     *                  | entity-header ) CRLF)  ; Section 7.1
     *                 CRLF
     *                 [ message-body ]          ; Section 7.2
     *
     * Status-Line = HTTP-Version SP Status-Code SP Reason-Phrase CRLF
     * Status-Code = 3DIGIT
     * Reason-Phrase  = *<TEXT, excluding CR, LF>
     *
     */

    private static final byte SP_CODE = (byte)32;
    private static final byte CR_CODE = (byte)13;
    private static final byte LF_CODE = (byte)10;
    private static final byte HT_CODE = (byte)9;

    private final HttpVersion version;
    private final HttpStatusCode statusCode;
    private final String reasonPhrase;

    private HttpHeader(byte[] rawData, int offset, int length) throws IllegalRawDataException {
      this.version = new HttpVersion(rawData, offset, length);

      int verLen = version.length();
      if (length < verLen + 7) {
        StringBuilder sb = new StringBuilder(100);
        sb.append("rawData is too short to build an HTTP header. rawData: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (rawData[verLen + offset] != SP_CODE) {
        StringBuilder sb = new StringBuilder(100);
        sb.append("No space after HTTP version. rawData: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      String scStr = new String(rawData, verLen + 1 + offset, 3);
      if (scStr.startsWith("-")) {
        throw new IllegalRawDataException("status code must be positive but: " + scStr);
      }
      this.statusCode = HttpStatusCode.getInstance(Short.valueOf(scStr));

      int scLen = 3;
      if (rawData[verLen + 1 + scLen + offset] != SP_CODE) {
        StringBuilder sb = new StringBuilder(100);
        sb.append("No space after HTTP status code. rawData: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      int reasonPhraseOffset = verLen + 1 + scLen + 1;
      int crlfIdx = -1;
      for (int i = reasonPhraseOffset; i < length - 1; i++) {
        if (rawData[i + offset] == CR_CODE) {
          if (rawData[i + 1 + offset] == LF_CODE) {
            crlfIdx = i;
            break;
          }
          else {
            StringBuilder sb = new StringBuilder(100);
            sb.append("An illegal CR is found in the Status-Line. rawData: ")
              .append(ByteArrays.toHexString(rawData, " "))
              .append(", offset: ")
              .append(offset)
              .append(", length: ")
              .append(length);
            throw new IllegalRawDataException(sb.toString());
          }
        }
        else if (rawData[i + offset] == LF_CODE) {
          StringBuilder sb = new StringBuilder(100);
          sb.append("An illegal LF is found in the Status-Line. rawData: ")
            .append(ByteArrays.toHexString(rawData, " "))
            .append(", offset: ")
            .append(offset)
            .append(", length: ")
            .append(length);
          throw new IllegalRawDataException(sb.toString());
        }
      }
      if (crlfIdx == -1) {
        StringBuilder sb = new StringBuilder(100);
        sb.append("No CR LF is found in the Status-Line. rawData: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.reasonPhrase
        = new String(
              rawData,
              reasonPhraseOffset + offset,
              crlfIdx - reasonPhraseOffset - offset
          );

    }

    private String nextHeader(byte[] rawData, int offset) throws IllegalRawDataException {
      return null;
//      if (rawData[offset] == SP_CODE || rawData[offset] == HT_CODE) {
//        // continuation of previous line
//      }
//
//      int crlfIdx = -1;
//      for (int i = offset; i < rawData.length - 1; i++) {
//        if (rawData[i] == CR_CODE) {
//          if (rawData[i + 1] == LF_CODE) {
//            crlfIdx = i;
//            break;
//          }
//          else {
//            throw new IllegalRawDataException(
//                    "An illegal CR is found in the Status-Line. rawData: "
//                      + ByteArrays.toHexString(rawData, " ")
//                  );
//          }
//        }
//        else if (rawData[i] == LF_CODE) {
//          throw new IllegalRawDataException(
//                  "An illegal LF is found in the Status-Line. rawData: "
//                    + ByteArrays.toHexString(rawData, " ")
//                );
//        }
//      }
//      if (crlfIdx == -1) {
//        throw new IllegalRawDataException(
//                "No CR LF is found in the Status-Line. rawData: "
//                  + ByteArrays.toHexString(rawData, " ")
//              );
//      }
    }

    private HttpHeader(Builder builder) {
      this.version = builder.version;
      this.statusCode = builder.statusCode;
      this.reasonPhrase = builder.reasonPhrase;
    }


    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(version.getRawData());
      rawFields.add(statusCode.valueAsString().getBytes());
      rawFields.add(reasonPhrase.getBytes());
      return rawFields;
    }

    @Override
    public int length() {
      return 0;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[HTTP Response Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Version: ")
        .append(version)
        .append(ls);
      sb.append("  Status Code: ")
        .append(statusCode.valueAsString())
        .append(ls);
      sb.append("  Reason Phrase: ")
        .append(reasonPhrase)
        .append(ls);

      return sb.toString();
    }

  }

}
