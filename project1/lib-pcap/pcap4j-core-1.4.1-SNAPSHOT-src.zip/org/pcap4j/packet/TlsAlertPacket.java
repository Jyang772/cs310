/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import static org.pcap4j.util.ByteArrays.*;
import java.util.ArrayList;
import java.util.List;
import org.pcap4j.packet.namednumber.TlsAlertDescription;
import org.pcap4j.packet.namednumber.TlsAlertLevel;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsAlertPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 1123151033301957691L;

  private final TlsAlertHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsAlertPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsAlertPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsAlertPacket(rawData, offset, length);
  }

  private TlsAlertPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsAlertHeader(rawData, offset, length);
  }

  private TlsAlertPacket(Builder builder) {
    if (
         builder == null
      || builder.level == null
      || builder.description == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.level: ").append(builder.level)
        .append(" builder.description: ").append(builder.description);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsAlertHeader(builder);
  }

  @Override
  public TlsAlertHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final
  class Builder extends AbstractBuilder {

    private TlsAlertLevel level;
    private TlsAlertDescription description;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsAlertPacket packet) {
      this.level = packet.header.level;
      this.description = packet.header.description;
    }

    /**
     *
     * @param level
     * @return this Builder object for method chaining.
     */
    public Builder level(TlsAlertLevel level) {
      this.level = level;
      return this;
    }

    /**
     *
     * @param description
     * @return this Builder object for method chaining.
     */
    public Builder description(TlsAlertDescription description) {
      this.description = description;
      return this;
    }

    @Override
    public TlsAlertPacket build() {
      return new TlsAlertPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsAlertHeader extends AbstractHeader {

    /*
     * struct {
     *
     *   AlertLevel level;
     *   AlertDescription description;
     *
     * } Alert;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = 7044757742781487040L;

    private static final int LEVEL_OFFSET
      = 0;
    private static final int LEVEL_SIZE
      = BYTE_SIZE_IN_BYTES;
    private static final int DESCRIPTION_OFFSET
      = LEVEL_OFFSET + LEVEL_SIZE;
    private static final int DESCRIPTION_SIZE
      = BYTE_SIZE_IN_BYTES;
    private static final int TLS_ALERT_HEADER_SIZE
      = DESCRIPTION_OFFSET + DESCRIPTION_SIZE;

    private final TlsAlertLevel level;
    private final TlsAlertDescription description;

    private TlsAlertHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_ALERT_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsAlertHeader (")
          .append(TLS_ALERT_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.level
        = TlsAlertLevel
            .getInstance(ByteArrays.getByte(rawData, LEVEL_OFFSET + offset));
      this.description
        = TlsAlertDescription
            .getInstance(ByteArrays.getByte(rawData, DESCRIPTION_OFFSET + offset));
    }

    private TlsAlertHeader(Builder builder) {
      this.level = builder.level;
      this.description = builder.description;
    }

    /**
     *
     * @return level
     */
    public TlsAlertLevel getLevel() {
      return level;
    }

    /**
     *
     * @return description
     */
    public TlsAlertDescription getDescription() {
      return description;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray(level.value()));
      rawFields.add(ByteArrays.toByteArray(description.value()));
      return rawFields;
    }

    @Override
    public int length() {
      return TLS_ALERT_HEADER_SIZE;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Alert Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Level: ")
        .append(level)
        .append(ls);
      sb.append("  Description: ")
        .append(description)
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsAlertHeader other = (TlsAlertHeader)obj;
      return
           level.equals(other.level)
        && description.equals(other.description);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + level.hashCode();
      result = 31 * result + description.hashCode();
      return result;
    }

  }

}
