/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsFinishedPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = -4495356310619118926L;

  private final TlsFinishedHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsFinishedPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsFinishedPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsFinishedPacket(rawData, offset, length);
  }

  private TlsFinishedPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsFinishedHeader(rawData, offset, length);
  }

  private TlsFinishedPacket(Builder builder) {
    if (
         builder == null
      || builder.verifyData == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.verifyData: ").append(builder.verifyData);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsFinishedHeader(builder);
  }

  @Override
  public TlsFinishedHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private byte[] verifyData;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsFinishedPacket packet) {
      this.verifyData = packet.header.verifyData;
    }

    /**
     *
     * @param verifyData
     * @return this Builder object for method chaining.
     */
    public Builder verifyData(byte[] verifyData) {
      this.verifyData = verifyData;
      return this;
    }

    @Override
    public TlsFinishedPacket build() {
      return new TlsFinishedPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsFinishedHeader extends AbstractHeader {

    /*
     * struct {
     *     opaque verify_data[12];
     * } Finished;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -3655924135458604613L;

    private static final int TLS_FINISHED_HEADER_SIZE = 12;

    private final byte[] verifyData;

    private TlsFinishedHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_FINISHED_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsFinishedHeader (")
          .append(TLS_FINISHED_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.verifyData
        = ByteArrays.getSubArray(rawData, offset, TLS_FINISHED_HEADER_SIZE);
    }

    private TlsFinishedHeader(Builder builder) {
      if (builder.verifyData.length != TLS_FINISHED_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("builder.verifyData.length must be ")
          .append(TLS_FINISHED_HEADER_SIZE)
          .append(". builder.verifyData: ")
          .append(ByteArrays.toHexString(builder.verifyData, " "));
        throw new IllegalArgumentException();
      }
      this.verifyData = ByteArrays.clone(builder.verifyData);
    }

    /**
     *
     * @return verifyData
     */
    public byte[] getVerifyData() {
      return ByteArrays.clone(verifyData);
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(verifyData);
      return rawFields;
    }

    @Override
    public int length() {
      return TLS_FINISHED_HEADER_SIZE;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Finished Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Verify Data: ")
        .append(ByteArrays.toHexString(verifyData, " "))
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsFinishedHeader other = (TlsFinishedHeader)obj;
      return Arrays.equals(verifyData, other.verifyData);
    }

    @Override
    protected int calcHashCode() {
      return Arrays.hashCode(verifyData);
    }

  }

}
