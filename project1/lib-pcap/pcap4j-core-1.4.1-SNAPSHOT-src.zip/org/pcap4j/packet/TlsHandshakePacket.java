/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import static org.pcap4j.util.ByteArrays.*;
import java.util.ArrayList;
import java.util.List;
import org.pcap4j.packet.factory.PacketFactories;
import org.pcap4j.packet.namednumber.TlsHandshakeType;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsHandshakePacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 7684805524178272458L;

  private final TlsHandshakeHeader header;
  private final Packet payload;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsHandshakePacket object.
   * @throws IllegalRawDataException
   */
  public static TlsHandshakePacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsHandshakePacket(rawData, offset, length);
  }

  private TlsHandshakePacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsHandshakeHeader(rawData, offset, length);

    int payloadLength = header.getLength();
    if (payloadLength > length - header.length()) {
      payloadLength = length - header.length();
    }

    if (header.getMsgType().equals(TlsHandshakeType.HELLO_REQUEST)) {
      this.payload = null;
    }
    else if (payloadLength > 0) {
      this.payload
        = PacketFactories.getFactory(Packet.class, TlsHandshakeType.class)
            .newInstance(rawData, offset + header.length(), payloadLength, header.getMsgType());
    }
    else {
      this.payload = null;
    }
  }

  private TlsHandshakePacket(Builder builder) {
    if (
         builder == null
      || builder.msgType == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.msgType: ").append(builder.msgType);
      throw new NullPointerException(sb.toString());
    }
    if ((builder.length & 0xFF000000) != 0) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder.length must be less than 16777216 but it is: ")
        .append(builder.length);
      throw new IllegalArgumentException(sb.toString());
    }

    this.payload = builder.payloadBuilder != null ? builder.payloadBuilder.build() : null;
    this.header = new TlsHandshakeHeader(
                    builder,
                    payload != null ? payload.length() : 0
                  );
  }

  @Override
  public TlsHandshakeHeader getHeader() {
    return header;
  }

  @Override
  public Packet getPayload() {
    return payload;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final
  class Builder extends AbstractBuilder
  implements LengthBuilder<TlsHandshakePacket> {

    private TlsHandshakeType msgType;
    private int length;
    private Packet.Builder payloadBuilder;
    private boolean correctLengthAtBuild;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsHandshakePacket packet) {
      this.msgType = packet.header.msgType;
      this.length = packet.header.length;
      this.payloadBuilder = packet.payload != null ? packet.payload.getBuilder() : null;
    }

    /**
     *
     * @param msgType
     * @return this Builder object for method chaining.
     */
    public Builder msgType(TlsHandshakeType msgType) {
      this.msgType = msgType;
      return this;
    }

    /**
     *
     * @param length
     * @return this Builder object for method chaining.
     */
    public Builder length(int length) {
      this.length = length;
      return this;
    }

    @Override
    public Builder payloadBuilder(Packet.Builder payloadBuilder) {
      this.payloadBuilder = payloadBuilder;
      return this;
    }

    @Override
    public Packet.Builder getPayloadBuilder() {
      return payloadBuilder;
    }

    @Override
    public Builder correctLengthAtBuild(boolean correctLengthAtBuild) {
      this.correctLengthAtBuild = correctLengthAtBuild;
      return this;
    }

    @Override
    public TlsHandshakePacket build() {
      return new TlsHandshakePacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsHandshakeHeader extends AbstractHeader {

    /*
     *  HandshakeType msg_type;    // handshake type
     *  uint24 length;             // bytes in message
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -7413646417416560581L;

    private static final int MSG_TYPE_OFFSET
      = 0;
    private static final int MSG_TYPE_SIZE
      = BYTE_SIZE_IN_BYTES;
    private static final int LENGTH_OFFSET
      = MSG_TYPE_OFFSET + MSG_TYPE_SIZE;
    private static final int LENGTH_SIZE
      = 3;
    private static final int TLS_HANDSHAKE_HEADER_SIZE
      = LENGTH_OFFSET + LENGTH_SIZE;

    private final TlsHandshakeType msgType;
    private final int length;

    private TlsHandshakeHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_HANDSHAKE_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsHandshakeHeader (")
          .append(TLS_HANDSHAKE_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.msgType
        = TlsHandshakeType
            .getInstance(ByteArrays.getByte(rawData, MSG_TYPE_OFFSET + offset));
      this.length
        =   ((0xFF & rawData[LENGTH_OFFSET + offset]) << 16)
          | ((0xFF & rawData[LENGTH_OFFSET + offset + 1]) << 8)
          | ((0xFF & rawData[LENGTH_OFFSET + offset + 2]));
    }

    private TlsHandshakeHeader(Builder builder, int payloadLength) {
      this.msgType = builder.msgType;

      if (builder.correctLengthAtBuild) {
        this.length = payloadLength;
      }
      else {
        this.length = builder.length;
      }
    }

    /**
     *
     * @return msgType
     */
    public TlsHandshakeType getMsgType() {
      return msgType;
    }

    /**
     *
     * @return length
     */
    public int getLength() {
      return length;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray(msgType.value()));
      rawFields.add(ByteArrays.toByteArray(length));
      return rawFields;
    }

    @Override
    public int length() {
      return TLS_HANDSHAKE_HEADER_SIZE;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Handshake Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Msg Type: ")
        .append(msgType)
        .append(ls);
      sb.append("  Length: ")
        .append(length)
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsHandshakeHeader other = (TlsHandshakeHeader)obj;
      return
           length == other.length
        && msgType.equals(other.msgType);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + msgType.hashCode();
      result = 31 * result + length;
      return result;
    }

  }

}
