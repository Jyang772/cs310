/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.Collections;
import java.util.List;
import org.pcap4j.packet.factory.PacketFactories;
import org.pcap4j.packet.namednumber.TlsSignatureAlgorithm;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsCertificateVerifyPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = -3788409872281665383L;

  private final TlsCertificateVerifyHeader header;
  private final Packet payload;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsCertificateVerifyPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsCertificateVerifyPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsCertificateVerifyPacket(rawData, offset, length);
  }

  private TlsCertificateVerifyPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsCertificateVerifyHeader(rawData, offset, length);

    int payloadLength = length - header.length();
    if (payloadLength != 0) { // payloadLength is positive.
      this.payload
        = PacketFactories.getFactory(Packet.class, TlsSignatureAlgorithm.class)
            .newInstance(
               rawData,
               offset + header.length(),
               payloadLength,
               header.getSignatureAlgorithm()
             );
    }
    else {
      this.payload = null;
    }
  }

  private TlsCertificateVerifyPacket(Builder builder) {
    if (
         builder == null
      || builder.signatureAlgorithm == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.signatureAlgorithm: ").append(builder.signatureAlgorithm);;
      throw new NullPointerException(sb.toString());
    }

    this.payload = builder.payloadBuilder != null ? builder.payloadBuilder.build() : null;
    this.header = new TlsCertificateVerifyHeader(builder);
  }

  @Override
  public TlsCertificateVerifyHeader getHeader() {
    return header;
  }

  @Override
  public Packet getPayload() {
    return payload;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private TlsSignatureAlgorithm signatureAlgorithm;
    private Packet.Builder payloadBuilder;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsCertificateVerifyPacket packet) {
      this.signatureAlgorithm = packet.header.signatureAlgorithm;
      this.payloadBuilder = packet.payload != null ? packet.payload.getBuilder() : null;
    }

    /**
     *
     * @param signatureAlgorithm
     * @return this Builder object for method chaining.
     */
    public Builder signatureAlgorithm(TlsSignatureAlgorithm signatureAlgorithm) {
      this.signatureAlgorithm = signatureAlgorithm;
      return this;
    }

    @Override
    public Builder payloadBuilder(Packet.Builder payloadBuilder) {
      this.payloadBuilder = payloadBuilder;
      return this;
    }

    @Override
    public Packet.Builder getPayloadBuilder() {
      return payloadBuilder;
    }

    @Override
    public TlsCertificateVerifyPacket build() {
      return new TlsCertificateVerifyPacket(this);
    }

  }

  /**
   * Pseudo header to hold a signature algorithm.
   *
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsCertificateVerifyHeader extends AbstractHeader {

    /*
     * struct {
     *     Signature signature;
     * } CertificateVerify;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -3302203880796170355L;

    private final TlsSignatureAlgorithm signatureAlgorithm; // pseudo field

    private TlsCertificateVerifyHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      this.signatureAlgorithm = TlsSignatureAlgorithm.ANONYMOUS; // TODO TLS session
    }

    private TlsCertificateVerifyHeader(Builder builder) {
      this.signatureAlgorithm = builder.signatureAlgorithm;
    }

    /**
     * @return signatureAlgorithm
     */
    public TlsSignatureAlgorithm getSignatureAlgorithm() {
      return signatureAlgorithm;
    }

    @Override
    protected List<byte[]> getRawFields() {
      return Collections.emptyList();
    }

    @Override
    public int length() {
      return 0;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Certificate Verify Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Signature Algorithm: ")
        .append(signatureAlgorithm)
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsCertificateVerifyHeader other = (TlsCertificateVerifyHeader)obj;
      return signatureAlgorithm.equals(other.signatureAlgorithm);
    }

    @Override
    protected int calcHashCode() {
      return signatureAlgorithm.hashCode();
    }

  }

}
