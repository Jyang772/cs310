/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Key Exchange Algorithm
 *
 * @see <a href="https://tools.ietf.org/html/rfc2246#appendix-A.4.2 (rsa, diffie_hellman)">RFC 2246</a>
 * @see <a href="http://tools.ietf.org/html/rfc2712#section-3 (krb5)">RFC 2712</a>
 * @see <a href="http://tools.ietf.org/html/rfc4279#section-2 (psk)">RFC 4279</a>
 * @see <a href="http://tools.ietf.org/html/rfc4492#section-5.4 (ec_diffie_hellman)">RFC 4492</a>
 * @see <a href="http://tools.ietf.org/html/rfc5054#section-2.8.2 (srp)">RFC 5054</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsKeyExchangeAlgorithm extends NamedNumber<Byte, TlsKeyExchangeAlgorithm> {

  /**
   *
   */
  private static final long serialVersionUID = 6218820671643878709L;

  /**
   * rsa server: 1
   */
  public static final TlsKeyExchangeAlgorithm RSA_SERVER
    = new TlsKeyExchangeAlgorithm((byte)1, "rsa");

  /**
   * rsa client: -1
   */
  public static final TlsKeyExchangeAlgorithm RSA_CLIENT
    = new TlsKeyExchangeAlgorithm((byte)-1, "rsa");

  /**
   * diffie_hellman server: 2
   */
  public static final TlsKeyExchangeAlgorithm DIFFIE_HELLMAN_SERVER
    = new TlsKeyExchangeAlgorithm((byte)2, "diffie_hellman");

  /**
   * diffie_hellman client: -2
   */
  public static final TlsKeyExchangeAlgorithm DIFFIE_HELLMAN_CLIENT
    = new TlsKeyExchangeAlgorithm((byte)-2, "diffie_hellman");

  /**
   * krb5 server: 3
   */
  public static final TlsKeyExchangeAlgorithm KRB5_SERVER
    = new TlsKeyExchangeAlgorithm((byte)3, "krb5");

  /**
   * krb5 client: -3
   */
  public static final TlsKeyExchangeAlgorithm KRB5_CLIENT
    = new TlsKeyExchangeAlgorithm((byte)-3, "krb5");

  /**
   * psk server: 4
   */
  public static final TlsKeyExchangeAlgorithm PSK_SERVER
    = new TlsKeyExchangeAlgorithm((byte)4, "psk");

  /**
   * psk client: -4
   */
  public static final TlsKeyExchangeAlgorithm PSK_CLIENT
    = new TlsKeyExchangeAlgorithm((byte)-4, "psk");

  /**
   * ec_diffie_hellman server: 5
   */
  public static final TlsKeyExchangeAlgorithm EC_DIFFIE_HELLMAN_SERVER
    = new TlsKeyExchangeAlgorithm((byte)5, "ec_diffie_hellman");

  /**
   * ec_diffie_hellman client: -5
   */
  public static final TlsKeyExchangeAlgorithm EC_DIFFIE_HELLMAN_CLIENT
    = new TlsKeyExchangeAlgorithm((byte)-5, "ec_diffie_hellman");

  /**
   * srp server: 6
   */
  public static final TlsKeyExchangeAlgorithm SRP_SERVER
    = new TlsKeyExchangeAlgorithm((byte)6, "srp");

  /**
   * srp client: -6
   */
  public static final TlsKeyExchangeAlgorithm SRP_CLIENT
    = new TlsKeyExchangeAlgorithm((byte)-6, "srp");

  private static final Map<Byte, TlsKeyExchangeAlgorithm> registry
    = new HashMap<Byte, TlsKeyExchangeAlgorithm>();

  static {
    registry.put(RSA_SERVER.value(), RSA_SERVER);
    registry.put(RSA_CLIENT.value(), RSA_CLIENT);
    registry.put(DIFFIE_HELLMAN_SERVER.value(), DIFFIE_HELLMAN_SERVER);
    registry.put(DIFFIE_HELLMAN_CLIENT.value(), DIFFIE_HELLMAN_CLIENT);
    registry.put(KRB5_SERVER.value(), KRB5_SERVER);
    registry.put(KRB5_CLIENT.value(), KRB5_CLIENT);
    registry.put(PSK_SERVER.value(), PSK_SERVER);
    registry.put(PSK_CLIENT.value(), PSK_CLIENT);
    registry.put(EC_DIFFIE_HELLMAN_SERVER.value(), EC_DIFFIE_HELLMAN_SERVER);
    registry.put(EC_DIFFIE_HELLMAN_CLIENT.value(), EC_DIFFIE_HELLMAN_CLIENT);
    registry.put(SRP_SERVER.value(), SRP_SERVER);
    registry.put(SRP_CLIENT.value(), SRP_CLIENT);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsKeyExchangeAlgorithm(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsKeyExchangeAlgorithm object.
   */
  public static TlsKeyExchangeAlgorithm getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsKeyExchangeAlgorithm(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsKeyExchangeAlgorithm object.
   */
  public static TlsKeyExchangeAlgorithm register(TlsKeyExchangeAlgorithm type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsKeyExchangeAlgorithm o) {
    return value().compareTo(o.value());
  }

}