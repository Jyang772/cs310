/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Client Certificate Type
 *
 * @see <a href="http://www.iana.org/assignments/tls-parameters/tls-parameters.xhtml#tls-parameters-2">IANA Registry</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsClientCertificateType extends NamedNumber<Byte, TlsClientCertificateType> {

  /**
   *
   */
  private static final long serialVersionUID = -3772322707439068086L;

  /**
   * rsa_sign: 1
   */
  public static final TlsClientCertificateType RSA_SIGN
    = new TlsClientCertificateType((byte)1, "rsa_sign");

  /**
   * dss_sign: 2
   */
  public static final TlsClientCertificateType DSS_SIGN
    = new TlsClientCertificateType((byte)2, "dss_sign");

  /**
   * rsa_fixed_dh: 3
   */
  public static final TlsClientCertificateType RSA_FIXED_DH
    = new TlsClientCertificateType((byte)3, "rsa_fixed_dh");

  /**
   * dss_fixed_dh: 4
   */
  public static final TlsClientCertificateType DSS_FIXED_DH
    = new TlsClientCertificateType((byte)4, "dss_fixed_dh");

  /**
   * rsa_ephemeral_dh: 5
   */
  public static final TlsClientCertificateType RSA_EPHEMERAL_DH
    = new TlsClientCertificateType((byte)5, "rsa_ephemeral_dh");

  /**
   * dss_ephemeral_dh: 6
   */
  public static final TlsClientCertificateType DSS_EPHEMERAL_DH
    = new TlsClientCertificateType((byte)6, "dss_ephemeral_dh");

  /**
   * fortezza_dms: 20
   */
  public static final TlsClientCertificateType FORTEZZA_DMS
    = new TlsClientCertificateType((byte)20, "fortezza_dms");

  /**
   * ecdsa_sign: 64
   */
  public static final TlsClientCertificateType ECDSA_SIGN
    = new TlsClientCertificateType((byte)64, "ecdsa_sign");

  /**
   * rsa_fixed_ecdh: 65
   */
  public static final TlsClientCertificateType RSA_FIXED_ECDH
    = new TlsClientCertificateType((byte)65, "rsa_fixed_ecdh");

  /**
   * ecdsa_fixed_ecdh: 66
   */
  public static final TlsClientCertificateType ECDSA_FIXED_ECDH
    = new TlsClientCertificateType((byte)66, "ecdsa_fixed_ecdh");

  private static final Map<Byte, TlsClientCertificateType> registry
    = new HashMap<Byte, TlsClientCertificateType>();

  static {
    registry.put(RSA_SIGN.value(), RSA_SIGN);
    registry.put(DSS_SIGN.value(), DSS_SIGN);
    registry.put(RSA_FIXED_DH.value(), RSA_FIXED_DH);
    registry.put(DSS_FIXED_DH.value(), DSS_FIXED_DH);
    registry.put(RSA_EPHEMERAL_DH.value(), RSA_EPHEMERAL_DH);
    registry.put(DSS_EPHEMERAL_DH.value(), DSS_EPHEMERAL_DH);
    registry.put(FORTEZZA_DMS.value(), FORTEZZA_DMS);
    registry.put(ECDSA_SIGN.value(), ECDSA_SIGN);
    registry.put(RSA_FIXED_ECDH.value(), RSA_FIXED_ECDH);
    registry.put(ECDSA_FIXED_ECDH.value(), ECDSA_FIXED_ECDH);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsClientCertificateType(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsClientCertificateType object.
   */
  public static TlsClientCertificateType getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsClientCertificateType(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsClientCertificateType object.
   */
  public static TlsClientCertificateType register(TlsClientCertificateType type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsClientCertificateType o) {
    return value().compareTo(o.value());
  }

}