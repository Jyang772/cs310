/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Change Cipher Spec Type
 *
 * @see <a href="http://tools.ietf.org/html/rfc2246#appendix-A.2">RFC 2246</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsChangeCipherSpecType extends NamedNumber<Byte, TlsChangeCipherSpecType> {

  /**
   *
   */
  private static final long serialVersionUID = 2945492144101417533L;

  /**
   * change_cipher_spec: 1
   */
  public static final TlsChangeCipherSpecType CHANGE_CIPHER_SPEC
    = new TlsChangeCipherSpecType((byte)1, "change_cipher_spec");

  private static final Map<Byte, TlsChangeCipherSpecType> registry
    = new HashMap<Byte, TlsChangeCipherSpecType>();

  static {
    registry.put(CHANGE_CIPHER_SPEC.value(), CHANGE_CIPHER_SPEC);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsChangeCipherSpecType(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsChangeCipherSpecType object.
   */
  public static TlsChangeCipherSpecType getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsChangeCipherSpecType(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsChangeCipherSpecType object.
   */
  public static TlsChangeCipherSpecType register(TlsChangeCipherSpecType type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsChangeCipherSpecType o) {
    return value().compareTo(o.value());
  }

}