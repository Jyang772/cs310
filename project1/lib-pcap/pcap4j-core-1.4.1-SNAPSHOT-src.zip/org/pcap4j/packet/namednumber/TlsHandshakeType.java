/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Handshake Type
 *
 * @see <a href="http://www.iana.org/assignments/tls-parameters/tls-parameters.xhtml#tls-parameters-7">IANA Registry</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsHandshakeType extends NamedNumber<Byte, TlsHandshakeType> {

  /**
   *
   */
  private static final long serialVersionUID = 7605032076930035333L;

  /**
   * hello_request: 0
   */
  public static final TlsHandshakeType HELLO_REQUEST
    = new TlsHandshakeType((byte)0, "hello_request");

  /**
   * client_hello: 1
   */
  public static final TlsHandshakeType CLIENT_HELLO
    = new TlsHandshakeType((byte)1, "client_hello");

  /**
   * server_hello: 2
   */
  public static final TlsHandshakeType SERVER_HELLO
    = new TlsHandshakeType((byte)2, "server_hello");

  /**
   * hello_verify_request: 3
   */
  public static final TlsHandshakeType HELLO_VERIFY_REQUEST
    = new TlsHandshakeType((byte)3, "hello_verify_request");

  /**
   * NewSessionTicket: 4
   */
  public static final TlsHandshakeType NEW_SESSION_TICKET
    = new TlsHandshakeType((byte)4, "NewSessionTicket");

  /**
   * certificate: 11
   */
  public static final TlsHandshakeType CERTIFICATE
    = new TlsHandshakeType((byte)11, "certificate");

  /**
   * server_key_exchange: 12
   */
  public static final TlsHandshakeType SERVER_KEY_EXCHANGE
    = new TlsHandshakeType((byte)12, "server_key_exchange");

  /**
   * certificate_request: 13
   */
  public static final TlsHandshakeType CERTIFICATE_REQUEST
    = new TlsHandshakeType((byte)13, "certificate_request");

  /**
   * server_hello_done: 14
   */
  public static final TlsHandshakeType SERVER_HELLO_DONE
    = new TlsHandshakeType((byte)14, "server_hello_done");

  /**
   * certificate_verify: 15
   */
  public static final TlsHandshakeType CERTIFICATE_VERIFY
    = new TlsHandshakeType((byte)15, "certificate_verify");

  /**
   * client_key_exchange: 16
   */
  public static final TlsHandshakeType CLIENT_KEY_EXCHANGE
    = new TlsHandshakeType((byte)16, "client_key_exchange");

  /**
   * finished: 20
   */
  public static final TlsHandshakeType FINISHED
    = new TlsHandshakeType((byte)20, "finished");

  /**
   * certificate_url: 21
   */
  public static final TlsHandshakeType CERTIFICATE_URL
    = new TlsHandshakeType((byte)21, "certificate_url");

  /**
   * certificate_status: 22
   */
  public static final TlsHandshakeType CERTIFICATE_STATUS
    = new TlsHandshakeType((byte)22, "certificate_status");

  /**
   * supplemental_data: 23
   */
  public static final TlsHandshakeType SUPPLEMENTAL_DATA
    = new TlsHandshakeType((byte)23, "supplemental_data");

  private static final Map<Byte, TlsHandshakeType> registry
    = new HashMap<Byte, TlsHandshakeType>();

  static {
    registry.put(HELLO_REQUEST.value(), HELLO_REQUEST);
    registry.put(CLIENT_HELLO.value(), CLIENT_HELLO);
    registry.put(SERVER_HELLO.value(), SERVER_HELLO);
    registry.put(HELLO_VERIFY_REQUEST.value(), HELLO_VERIFY_REQUEST);
    registry.put(NEW_SESSION_TICKET.value(), NEW_SESSION_TICKET);
    registry.put(CERTIFICATE.value(), CERTIFICATE);
    registry.put(SERVER_KEY_EXCHANGE.value(), SERVER_KEY_EXCHANGE);
    registry.put(CERTIFICATE_REQUEST.value(), CERTIFICATE_REQUEST);
    registry.put(SERVER_HELLO_DONE.value(), SERVER_HELLO_DONE);
    registry.put(CERTIFICATE_VERIFY.value(), CERTIFICATE_VERIFY);
    registry.put(CLIENT_KEY_EXCHANGE.value(), CLIENT_KEY_EXCHANGE);
    registry.put(FINISHED.value(), FINISHED);
    registry.put(CERTIFICATE_URL.value(), CERTIFICATE_URL);
    registry.put(CERTIFICATE_STATUS.value(), CERTIFICATE_STATUS);
    registry.put(SUPPLEMENTAL_DATA.value(), SUPPLEMENTAL_DATA);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsHandshakeType(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsHandshakeType object.
   */
  public static TlsHandshakeType getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsHandshakeType(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsHandshakeType object.
   */
  public static TlsHandshakeType register(TlsHandshakeType type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsHandshakeType o) {
    return value().compareTo(o.value());
  }

}