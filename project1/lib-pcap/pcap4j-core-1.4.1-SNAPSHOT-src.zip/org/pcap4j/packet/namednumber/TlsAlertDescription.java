/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Alert Description
 *
 * @see <a href="http://tools.ietf.org/html/rfc2246#appendix-A.3">RFC 2246</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsAlertDescription extends NamedNumber<Byte, TlsAlertDescription> {

  /**
   *
   */
  private static final long serialVersionUID = -6085471909223478449L;

  /**
   * close_notify: 0
   */
  public static final TlsAlertDescription CLOSE_NOTIFY
    = new TlsAlertDescription((byte)0, "close_notify");

  /**
   * unexpected_message: 10
   */
  public static final TlsAlertDescription UNEXPECTED_MESSAGE
    = new TlsAlertDescription((byte)10, "unexpected_message");

  /**
   * bad_record_mac: 20
   */
  public static final TlsAlertDescription BAD_RECORD_MAC
    = new TlsAlertDescription((byte)20, "bad_record_mac");

  /**
   * decryption_failed: 21
   */
  public static final TlsAlertDescription DECRYPTION_FAILED
    = new TlsAlertDescription((byte)21, "decryption_failed");

  /**
   * record_overflow: 22
   */
  public static final TlsAlertDescription RECORD_OVERFLOW
    = new TlsAlertDescription((byte)22, "record_overflow");

  /**
   * decompression_failure: 30
   */
  public static final TlsAlertDescription DECOMPRESSION_FAILURE
    = new TlsAlertDescription((byte)30, "decompression_failure");

  /**
   * handshake_failure: 40
   */
  public static final TlsAlertDescription HANDSHAKE_FAILURE
    = new TlsAlertDescription((byte)40, "handshake_failure");

  /**
   * bad_certificate: 42
   */
  public static final TlsAlertDescription BAD_CERTIFICATE
    = new TlsAlertDescription((byte)42, "bad_certificate");

  /**
   * unsupported_certificate: 43
   */
  public static final TlsAlertDescription UNSUPPORTED_CERTIFICATE
    = new TlsAlertDescription((byte)43, "unsupported_certificate");

  /**
   * certificate_revoked: 44
   */
  public static final TlsAlertDescription CERTIFICATE_REVOKED
    = new TlsAlertDescription((byte)44, "certificate_revoked");

  /**
   * certificate_expired: 45
   */
  public static final TlsAlertDescription CERTIFICATE_EXPIRED
    = new TlsAlertDescription((byte)45, "certificate_expired");

  /**
   * certificate_unknown: 46
   */
  public static final TlsAlertDescription CERTIFICATE_UNKNOWN
    = new TlsAlertDescription((byte)46, "certificate_unknown");

  /**
   * illegal_parameter: 47
   */
  public static final TlsAlertDescription ILLEGAL_PARAMETER
    = new TlsAlertDescription((byte)47, "illegal_parameter");

  /**
   * unknown_ca: 48
   */
  public static final TlsAlertDescription UNKNOWN_CA
    = new TlsAlertDescription((byte)48, "unknown_ca");

  /**
   * access_denied: 49
   */
  public static final TlsAlertDescription ACCESS_DENIED
    = new TlsAlertDescription((byte)49, "access_denied");

  /**
   * decode_error: 50
   */
  public static final TlsAlertDescription DECODE_ERROR
    = new TlsAlertDescription((byte)50, "decode_error");

  /**
   * decrypt_error: 51
   */
  public static final TlsAlertDescription DECRYPT_ERROR
    = new TlsAlertDescription((byte)51, "decrypt_error");

  /**
   * export_restriction: 60
   */
  public static final TlsAlertDescription EXPORT_RESTRICTION
    = new TlsAlertDescription((byte)60, "export_restriction");

  /**
   * protocol_version: 70
   */
  public static final TlsAlertDescription PROTOCOL_VERSION
    = new TlsAlertDescription((byte)70, "protocol_version");

  /**
   * insufficient_security: 71
   */
  public static final TlsAlertDescription INSUFFICIENT_SECURITY
    = new TlsAlertDescription((byte)71, "insufficient_security");

  /**
   * internal_error: 80
   */
  public static final TlsAlertDescription INTERNAL_ERROR
    = new TlsAlertDescription((byte)80, "internal_error");

  /**
   * user_canceled: 90
   */
  public static final TlsAlertDescription USER_CANCELED
    = new TlsAlertDescription((byte)90, "user_canceled");

  /**
   * no_renegotiation: 100
   */
  public static final TlsAlertDescription NO_RENEGOTIATION
    = new TlsAlertDescription((byte)100, "no_renegotiation");

  private static final Map<Byte, TlsAlertDescription> registry
    = new HashMap<Byte, TlsAlertDescription>();

  static {
    registry.put(CLOSE_NOTIFY.value(), CLOSE_NOTIFY);
    registry.put(UNEXPECTED_MESSAGE.value(), UNEXPECTED_MESSAGE);
    registry.put(BAD_RECORD_MAC.value(), BAD_RECORD_MAC);
    registry.put(DECRYPTION_FAILED.value(), DECRYPTION_FAILED);
    registry.put(RECORD_OVERFLOW.value(), RECORD_OVERFLOW);
    registry.put(DECOMPRESSION_FAILURE.value(), DECOMPRESSION_FAILURE);
    registry.put(HANDSHAKE_FAILURE.value(), HANDSHAKE_FAILURE);
    registry.put(BAD_CERTIFICATE.value(), BAD_CERTIFICATE);
    registry.put(UNSUPPORTED_CERTIFICATE.value(), UNSUPPORTED_CERTIFICATE);
    registry.put(CERTIFICATE_REVOKED.value(), CERTIFICATE_REVOKED);
    registry.put(CERTIFICATE_EXPIRED.value(), CERTIFICATE_EXPIRED);
    registry.put(CERTIFICATE_UNKNOWN.value(), CERTIFICATE_UNKNOWN);
    registry.put(ILLEGAL_PARAMETER.value(), ILLEGAL_PARAMETER);
    registry.put(UNKNOWN_CA.value(), UNKNOWN_CA);
    registry.put(ACCESS_DENIED.value(), ACCESS_DENIED);
    registry.put(DECODE_ERROR.value(), DECODE_ERROR);
    registry.put(DECRYPT_ERROR.value(), DECRYPT_ERROR);
    registry.put(EXPORT_RESTRICTION.value(), EXPORT_RESTRICTION);
    registry.put(PROTOCOL_VERSION.value(), PROTOCOL_VERSION);
    registry.put(INSUFFICIENT_SECURITY.value(), INSUFFICIENT_SECURITY);
    registry.put(INTERNAL_ERROR.value(), INTERNAL_ERROR);
    registry.put(USER_CANCELED.value(), USER_CANCELED);
    registry.put(NO_RENEGOTIATION.value(), NO_RENEGOTIATION);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsAlertDescription(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsAlertDescription object.
   */
  public static TlsAlertDescription getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsAlertDescription(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsAlertDescription object.
   */
  public static TlsAlertDescription register(TlsAlertDescription type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsAlertDescription o) {
    return value().compareTo(o.value());
  }

}