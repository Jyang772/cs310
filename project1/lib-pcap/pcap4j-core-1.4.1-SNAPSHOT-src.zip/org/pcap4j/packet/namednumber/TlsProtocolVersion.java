/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Protocol Version
 *
 * @see <a href="https://tools.ietf.org/html/rfc2246#appendix-A.1">RFC 2246</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsProtocolVersion extends NamedNumber<Short, TlsProtocolVersion> {

  /**
   *
   */
  private static final long serialVersionUID = -163142407864530104L;

  /**
   * SSL 3.0: 0x0300
   */
  public static final TlsProtocolVersion SSL_3_0
    = new TlsProtocolVersion((short)0x0300, "SSL 3.0");

  /**
   * TLS 1.0: 0x0301
   */
  public static final TlsProtocolVersion TLS_1_0
    = new TlsProtocolVersion((short)0x0301, "TLS 1.0");

  /**
   * TLS 1.1: 0x0302
   */
  public static final TlsProtocolVersion TLS_1_1
    = new TlsProtocolVersion((short)0x0302, "TLS 1.1");

  /**
   * TLS 1.2: 0x0303
   */
  public static final TlsProtocolVersion TLS_1_2
    = new TlsProtocolVersion((short)0x0303, "TLS 1.2");

  /**
   * TLS 1.3: 0x0806
   */
  public static final TlsProtocolVersion TLS_1_3
    = new TlsProtocolVersion((short)0x0806, "TLS 1.3");

  private static final Map<Short, TlsProtocolVersion> registry
    = new HashMap<Short, TlsProtocolVersion>();

  static {
    registry.put(SSL_3_0.value(), SSL_3_0);
    registry.put(TLS_1_0.value(), TLS_1_0);
    registry.put(TLS_1_1.value(), TLS_1_1);
    registry.put(TLS_1_2.value(), TLS_1_2);
    registry.put(TLS_1_3.value(), TLS_1_3);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsProtocolVersion(Short value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsVersion object.
   */
  public static TlsProtocolVersion getInstance(Short value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsProtocolVersion(value, "unknown");
    }
  }

  /**
   *
   * @param major 0 to 255
   * @param minor 0 to 255
   * @return a TlsVersion object.
   */
  public static TlsProtocolVersion getInstance(int major, int minor) {
    if ((major & 0xFFFFFF00) != 0) {
      throw new IllegalArgumentException("major must be between 0 and 255, but it is: " + major);
    }
    if ((minor & 0xFFFFFF00) != 0) {
      throw new IllegalArgumentException("minor must be between 0 and 255, but it is: " + minor);
    }
    return TlsProtocolVersion.getInstance(Short.valueOf((short)((major << 8) | minor)));
  }

  /**
   *
   * @param type
   * @return a TlsVersion object.
   */
  public static TlsProtocolVersion register(TlsProtocolVersion type) {
    return registry.put(type.value(), type);
  }

  /**
   *
   * @return a string representation of this value.
   */
  @Override
  public String valueAsString() {
    StringBuilder sb = new StringBuilder(5);
    sb.append((value() >> 8) & 0xFF)
      .append(".")
      .append(value() & 0xFF);
    return sb.toString();
  }

  @Override
  public int compareTo(TlsProtocolVersion o) {
    return value().compareTo(o.value());
  }

}