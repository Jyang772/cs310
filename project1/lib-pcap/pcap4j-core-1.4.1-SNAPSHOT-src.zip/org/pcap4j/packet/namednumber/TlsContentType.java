/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Content Type
 *
 * @see <a href="http://www.iana.org/assignments/tls-parameters/tls-parameters.xhtml#tls-parameters-5">IANA Registry</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsContentType extends NamedNumber<Byte, TlsContentType> {

  /**
   *
   */
  private static final long serialVersionUID = -8525871874819347924L;

  /**
   * change_cipher_spec: 20
   */
  public static final TlsContentType CHANGE_CIPHER_SPEC
    = new TlsContentType((byte)20, "change_cipher_spec");

  /**
   * alert: 21
   */
  public static final TlsContentType ALERT
    = new TlsContentType((byte)21, "alert");

  /**
   * handshake: 22
   */
  public static final TlsContentType HANDSHAKE
    = new TlsContentType((byte)22, "handshake");

  /**
   * application_data: 23
   */
  public static final TlsContentType APPLICATION_DATA
    = new TlsContentType((byte)23, "application_data");

  /**
   * heartbeat: 24
   */
  public static final TlsContentType HEARTBEAT
    = new TlsContentType((byte)24, "heartbeat");

  private static final Map<Byte, TlsContentType> registry
    = new HashMap<Byte, TlsContentType>();

  static {
    registry.put(CHANGE_CIPHER_SPEC.value(), CHANGE_CIPHER_SPEC);
    registry.put(ALERT.value(), ALERT);
    registry.put(HANDSHAKE.value(), HANDSHAKE);
    registry.put(APPLICATION_DATA.value(), APPLICATION_DATA);
    registry.put(HEARTBEAT.value(), HEARTBEAT);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsContentType(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsContentType object.
   */
  public static TlsContentType getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsContentType(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsContentType object.
   */
  public static TlsContentType register(TlsContentType type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsContentType o) {
    return value().compareTo(o.value());
  }

}