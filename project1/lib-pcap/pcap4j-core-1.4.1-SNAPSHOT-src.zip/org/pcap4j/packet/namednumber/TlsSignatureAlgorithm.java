/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Signature Algorithm
 *
 * @see <a href="http://www.iana.org/assignments/tls-parameters/tls-parameters.xhtml#tls-parameters-16">IANA Registry</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsSignatureAlgorithm extends NamedNumber<Byte, TlsSignatureAlgorithm> {

  /**
   *
   */
  private static final long serialVersionUID = -836994045116799295L;

  /**
   * anonymous: 0
   */
  public static final TlsSignatureAlgorithm ANONYMOUS
    = new TlsSignatureAlgorithm((byte)0, "anonymous");

  /**
   * rsa: 1
   */
  public static final TlsSignatureAlgorithm RSA
    = new TlsSignatureAlgorithm((byte)1, "rsa");

  /**
   * dsa: 2
   */
  public static final TlsSignatureAlgorithm DSA
    = new TlsSignatureAlgorithm((byte)2, "dsa");

  /**
   * ecdsa: 3
   */
  public static final TlsSignatureAlgorithm ECDSA
    = new TlsSignatureAlgorithm((byte)3, "ecdsa");

  private static final Map<Byte, TlsSignatureAlgorithm> registry
    = new HashMap<Byte, TlsSignatureAlgorithm>();

  static {
    registry.put(ANONYMOUS.value(), ANONYMOUS);
    registry.put(RSA.value(), RSA);
    registry.put(DSA.value(), DSA);
    registry.put(ECDSA.value(), ECDSA);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsSignatureAlgorithm(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsSignatureAlgorithm object.
   */
  public static TlsSignatureAlgorithm getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsSignatureAlgorithm(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsSignatureAlgorithm object.
   */
  public static TlsSignatureAlgorithm register(TlsSignatureAlgorithm type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsSignatureAlgorithm o) {
    return value().compareTo(o.value());
  }

}