/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Compression Method
 *
 * @see <a href="http://tools.ietf.org/html/rfc2246#appendix-A.4.1">RFC 2246</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsCompressionMethod extends NamedNumber<Byte, TlsCompressionMethod> {

  /**
   *
   */
  private static final long serialVersionUID = 7795160842715346169L;

  /**
   * null: 0
   */
  public static final TlsCompressionMethod NULL
    = new TlsCompressionMethod((byte)0, "null");

  private static final Map<Byte, TlsCompressionMethod> registry
    = new HashMap<Byte, TlsCompressionMethod>();

  static {
    registry.put(NULL.value(), NULL);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsCompressionMethod(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsCompressionMethod object.
   */
  public static TlsCompressionMethod getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsCompressionMethod(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsCompressionMethod object.
   */
  public static TlsCompressionMethod register(TlsCompressionMethod type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsCompressionMethod o) {
    return value().compareTo(o.value());
  }

}