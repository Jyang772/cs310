/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet.namednumber;

import java.util.HashMap;
import java.util.Map;

/**
 * TLS Alert Level
 *
 * @see <a href="http://tools.ietf.org/html/rfc2246#appendix-A.3">RFC 2246</a>
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsAlertLevel extends NamedNumber<Byte, TlsAlertLevel> {

  /**
   *
   */
  private static final long serialVersionUID = 9158221636723394411L;

  /**
   * warning: 1
   */
  public static final TlsAlertLevel WARNING
    = new TlsAlertLevel((byte)1, "warning");

  /**
   *  fatal: 2
   */
  public static final TlsAlertLevel FATAL
    = new TlsAlertLevel((byte)2, "fatal");

  private static final Map<Byte, TlsAlertLevel> registry
    = new HashMap<Byte, TlsAlertLevel>();

  static {
    registry.put(WARNING.value(), WARNING);
    registry.put(FATAL.value(), FATAL);
  }

  /**
   *
   * @param value
   * @param name
   */
  public TlsAlertLevel(Byte value, String name) {
    super(value, name);
  }

  /**
   *
   * @param value
   * @return a TlsAlertLevel object.
   */
  public static TlsAlertLevel getInstance(Byte value) {
    if (registry.containsKey(value)) {
      return registry.get(value);
    }
    else {
      return new TlsAlertLevel(value, "unknown");
    }
  }

  /**
   *
   * @param type
   * @return a TlsAlertLevel object.
   */
  public static TlsAlertLevel register(TlsAlertLevel type) {
    return registry.put(type.value(), type);
  }

  @Override
  public String valueAsString() {
    return String.valueOf(value() & 0xFF);
  }

  @Override
  public int compareTo(TlsAlertLevel o) {
    return value().compareTo(o.value());
  }

}