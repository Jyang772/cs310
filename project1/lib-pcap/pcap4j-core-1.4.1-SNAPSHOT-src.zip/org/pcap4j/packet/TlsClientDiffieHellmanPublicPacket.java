/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsClientDiffieHellmanPublicPacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 5485371430518957788L;

  private final TlsClientDiffieHellmanPublicHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsClientDiffieHellmanPublicPacket object.
   * @throws IllegalRawDataException
   */
  public static TlsClientDiffieHellmanPublicPacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsClientDiffieHellmanPublicPacket(rawData, offset, length);
  }

  private TlsClientDiffieHellmanPublicPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsClientDiffieHellmanPublicHeader(rawData, offset, length);
  }

  private TlsClientDiffieHellmanPublicPacket(Builder builder) {
    if (
         builder == null
      || builder.dhYc == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.dhYc: ").append(builder.dhYc);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsClientDiffieHellmanPublicHeader(builder);
  }

  @Override
  public TlsClientDiffieHellmanPublicHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private byte[] dhYc;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsClientDiffieHellmanPublicPacket packet) {
      this.dhYc = packet.header.dhYc;
    }

    /**
     *
     * @param dhYc
     * @return this Builder object for method chaining.
     */
    public Builder dhYc(byte[] dhYc) {
      this.dhYc = dhYc;
      return this;
    }

    @Override
    public TlsClientDiffieHellmanPublicPacket build() {
      return new TlsClientDiffieHellmanPublicPacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsClientDiffieHellmanPublicHeader extends AbstractHeader {

    /*
     * enum { implicit, explicit } PublicValueEncoding;
     *
     * implicit
     *     If the client certificate already contains a suitable
     *     Diffie-Hellman key, then Yc is implicit and does not need to
     *     be sent again. In this case, the Client Key Exchange message
     *     will be sent, but will be empty.
     *
     * explicit
     *     Yc needs to be sent.
     *
     * struct {
     *     select (PublicValueEncoding) {
     *         case implicit: struct { };
     *         case explicit: opaque dh_Yc<1..2^16-1>;
     *     } dh_public;
     * } ClientDiffieHellmanPublic;
     *
     * dh_Yc
     *     The client's Diffie-Hellman public value (Yc).
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -1932851032059066443L;

    private static final int MIN_TLS_CLIENT_DIFFIE_HELLMAN_PUBLIC_HEADER_SIZE
      = 3;

    private final byte[] dhYc;

    private TlsClientDiffieHellmanPublicHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < MIN_TLS_CLIENT_DIFFIE_HELLMAN_PUBLIC_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsClientDiffieHellmanPublicHeader (")
          .append(MIN_TLS_CLIENT_DIFFIE_HELLMAN_PUBLIC_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      int curRelOffset = 0;
      int ycLen = ByteArrays.getInt(rawData, curRelOffset + offset, 2);
      curRelOffset += 2;
      if (curRelOffset + ycLen > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get dh_p. ")
          .append("The data is too short to build an TlsClientDiffieHellmanPublicHeader (")
          .append(curRelOffset + ycLen)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (ycLen < 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_Yc length must be more than 0 but is: ")
          .append(ycLen)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (ycLen > (1 << 16) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("dh_Yc length must be less than (1 << 16) but is: ")
          .append(ycLen)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      this.dhYc
        = ByteArrays.getSubArray(rawData, curRelOffset + offset, ycLen);
    }

    private TlsClientDiffieHellmanPublicHeader(Builder builder) {
      this.dhYc = ByteArrays.clone(builder.dhYc);
    }

    /**
     *
     * @return dhYc
     */
    public byte[] getDhYc() {
      return ByteArrays.clone(dhYc);
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(ByteArrays.toByteArray((short)dhYc.length));
      rawFields.add(dhYc);
      return rawFields;
    }

    @Override
    public int length() {
      return dhYc.length + 2;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS Client Diffie-Hellman Public Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  dh_Yc: ")
        .append(ByteArrays.toHexString(dhYc, " "))
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsClientDiffieHellmanPublicHeader other = (TlsClientDiffieHellmanPublicHeader)obj;
      return Arrays.equals(dhYc, other.dhYc);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + Arrays.hashCode(dhYc);
      return result;
    }

  }

}
