/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsRsaSignaturePacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = 8649696351692307850L;

  private final TlsRsaSignatureHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsRsaSignaturePacket object.
   * @throws IllegalRawDataException
   */
  public static TlsRsaSignaturePacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    return new TlsRsaSignaturePacket(rawData, offset, length);
  }

  private TlsRsaSignaturePacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    this.header = new TlsRsaSignatureHeader(rawData, offset, length);
  }

  private TlsRsaSignaturePacket(Builder builder) {
    if (
         builder == null
      || builder.md5Hash == null
      || builder.shaHash == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.md5Hash: ").append(builder.md5Hash)
        .append(" builder.shaHash: ").append(builder.shaHash);
      throw new NullPointerException(sb.toString());
    }

    this.header = new TlsRsaSignatureHeader(builder);
  }

  @Override
  public TlsRsaSignatureHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends AbstractBuilder {

    private byte[] md5Hash;
    private byte[] shaHash;

    /**
     *
     */
    public Builder() {}

    private Builder(TlsRsaSignaturePacket packet) {
      this.md5Hash = packet.header.md5Hash;
      this.shaHash = packet.header.shaHash;
    }

    /**
     *
     * @param md5Hash
     * @return this Builder object for method chaining.
     */
    public Builder md5Hash(byte[] md5Hash) {
      this.md5Hash = md5Hash;
      return this;
    }

    /**
     *
     * @param shaHash
     * @return this Builder object for method chaining.
     */
    public Builder shaHash(byte[] shaHash) {
      this.shaHash = shaHash;
      return this;
    }

    @Override
    public TlsRsaSignaturePacket build() {
      return new TlsRsaSignaturePacket(this);
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsRsaSignatureHeader extends AbstractHeader {

    /*
     *  digitally-signed struct {
     *
     *     opaque md5_hash[16];
     *     opaque sha_hash[20];
     *
     * };
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -3925962919229052817L;

    private static final int MD5_HASH_OFFSET
      = 0;
    private static final int MD5_HASH_SIZE
      = 16;
    private static final int SHA_HASH_OFFSET
      = MD5_HASH_OFFSET + MD5_HASH_SIZE;
    private static final int SHA_HASH__SIZE
      = 20;
    private static final int TLS_RSA_SIGNATURE_HEADER_SIZE
      = SHA_HASH_OFFSET + SHA_HASH__SIZE;

    private final byte[] md5Hash;
    private final byte[] shaHash;

    private TlsRsaSignatureHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_RSA_SIGNATURE_HEADER_SIZE) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsRsaSignatureHeader (")
          .append(TLS_RSA_SIGNATURE_HEADER_SIZE)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      this.md5Hash
        = ByteArrays.getSubArray(rawData, MD5_HASH_OFFSET + offset, MD5_HASH_SIZE);
      this.shaHash
        = ByteArrays.getSubArray(rawData, SHA_HASH_OFFSET + offset, SHA_HASH__SIZE);
    }

    private TlsRsaSignatureHeader(Builder builder) {
      this.md5Hash = ByteArrays.clone(builder.md5Hash);
      this.shaHash = ByteArrays.clone(builder.shaHash);
    }

    /**
     *
     * @return md5Hash
     */
    public byte[] getMd5Hash() {
      return ByteArrays.clone(md5Hash);
    }

    /**
     *
     * @return shaHash
     */
    public byte[] getShaHash() {
      return ByteArrays.clone(shaHash);
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new ArrayList<byte[]>();
      rawFields.add(md5Hash);
      rawFields.add(shaHash);
      return rawFields;
    }

    @Override
    public int length() {
      return TLS_RSA_SIGNATURE_HEADER_SIZE;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[TLS RSA Signature Header (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  MD5 Hash: ")
        .append(ByteArrays.toHexString(md5Hash, " "))
        .append(ls);
      sb.append("  SHA Hash: ")
        .append(ByteArrays.toHexString(shaHash, " "))
        .append(ls);

      return sb.toString();
    }

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsRsaSignatureHeader other = (TlsRsaSignatureHeader)obj;
      return
           Arrays.equals(md5Hash, other.md5Hash)
        && Arrays.equals(shaHash, other.shaHash);
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      result = 31 * result + Arrays.hashCode(md5Hash);
      result = 31 * result + Arrays.hashCode(shaHash);
      return result;
    }

  }

}
