/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsClientKeyExchangePacket extends TlsAbstractKeyExchangePacket {

  /**
   *
   */
  private static final long serialVersionUID = 2260162758897732445L;

  private final TlsClientKeyExchangeHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsClientKeyExchangePacket object.
   * @throws IllegalRawDataException
   */
  public static TlsClientKeyExchangePacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    TlsClientKeyExchangeHeader header = new TlsClientKeyExchangeHeader(rawData, offset, length);
    return new TlsClientKeyExchangePacket(rawData, offset, length, header);
  }

  private TlsClientKeyExchangePacket(
    byte[] rawData, int offset, int length, TlsClientKeyExchangeHeader header
  ) throws IllegalRawDataException {
    super(rawData, offset, length, header);
    this.header = header;
  }

  private TlsClientKeyExchangePacket(Builder builder) {
    super(builder);
    this.header = new TlsClientKeyExchangeHeader(builder);
  }

  @Override
  public TlsClientKeyExchangeHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends TlsAbstractKeyExchangePacket.Builder {

    /**
     *
     */
    public Builder() {}

    private Builder(TlsClientKeyExchangePacket packet) {
      super(packet);
    }

    @Override
    public TlsClientKeyExchangePacket build() {
      return new TlsClientKeyExchangePacket(this);
    }

  }

  /**
   * Pseudo header to hold a key exchange algorithm.
   *
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsClientKeyExchangeHeader extends TlsAbstractKeyExchangeHeader {

    /*
     * struct {
     *     select (KeyExchangeAlgorithm) {
     *         case rsa: EncryptedPreMasterSecret;
     *         case diffie_hellman: ClientDiffieHellmanPublic;
     *     } exchange_keys;
     * } ClientKeyExchange;
     */

    /**
     *
     */
    private static final long serialVersionUID = -7353928844709021050L;

    private TlsClientKeyExchangeHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      super(rawData, offset, length);
    }

    private TlsClientKeyExchangeHeader(Builder builder) {
      super(builder);
    }

    @Override
    protected String getHeaderName() {
      return "TLS Client Key Exchange Header";
    }

  }

}
