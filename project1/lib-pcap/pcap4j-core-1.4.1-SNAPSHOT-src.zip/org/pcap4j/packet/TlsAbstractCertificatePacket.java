/*_##########################################################################
  _##
  _##  Copyright (C) 2014  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
abstract class TlsAbstractCertificatePacket extends AbstractPacket {

  /**
   *
   */
  private static final long serialVersionUID = -4650721471065461389L;

  protected TlsAbstractCertificatePacket() {}

  protected TlsAbstractCertificatePacket(Builder builder) {
    if (
         builder == null
      || builder.certificateList == null
    ) {
      StringBuilder sb = new StringBuilder();
      sb.append("builder: ").append(builder)
        .append(" builder.certificateList: ").append(builder.certificateList);
      throw new NullPointerException(sb.toString());
    }
  }

  @Override
  public abstract TlsAbstractCertificateHeader getHeader();

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  static abstract class Builder extends AbstractBuilder {

    private List<byte[]> certificateList;

    /**
     *
     */
    public Builder() {}

    protected Builder(TlsAbstractCertificatePacket packet) {
      this.certificateList = packet.getHeader().certificateList;
    }

    /**
     *
     * @param certificateList
     * @return this Builder object for method chaining.
     */
    public Builder certificateList(List<byte[]> certificateList) {
      this.certificateList = certificateList;
      return this;
    }

  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  static abstract class TlsAbstractCertificateHeader extends AbstractHeader {

    /*
     * opaque ASN.1Cert<1..2^24-1>;
     * struct {
     *
     *     ASN.1Cert certificate_list<0..2^24-1>;
     *
     * } Certificate;
     *
     */

    /**
     *
     */
    private static final long serialVersionUID = -4673908057215030922L;

    private static final int TLS_CERTIFICATE_HEADER_MIN = 6;

    private final List<byte[]> certificateList = new ArrayList<byte[]>();

    protected TlsAbstractCertificateHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      if (length < TLS_CERTIFICATE_HEADER_MIN) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("The data is too short to build an TlsAbstractCertificateHeader (")
          .append(TLS_CERTIFICATE_HEADER_MIN)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      int curRelOffset = 0;
      int certificateListLength = ByteArrays.getInt(rawData, offset, 3);
      curRelOffset += 3;
      if (curRelOffset + certificateListLength > length) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("Can't get certificate_list. ")
          .append("The data is too short to build an TlsAbstractCertificateHeader (")
          .append(curRelOffset + certificateListLength)
          .append(" bytes). data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (certificateListLength < 3) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("certificate_list length must be more than 2 but is: ")
          .append(certificateListLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }
      if (certificateListLength > (1 << 24) - 1) {
        StringBuilder sb = new StringBuilder(80);
        sb.append("certificate_list length must be less than (1 << 24) but is: ")
          .append(certificateListLength)
          .append(". data: ")
          .append(ByteArrays.toHexString(rawData, " "))
          .append(", offset: ")
          .append(offset)
          .append(", length: ")
          .append(length);
        throw new IllegalRawDataException(sb.toString());
      }

      for (int processedBytes = 0; processedBytes < certificateListLength;) {
        if (processedBytes + 3 > certificateListLength) {
          StringBuilder sb = new StringBuilder(80);
          sb.append("Can't get certificateLength. certificateListLength: ")
            .append(certificateListLength)
            .append(", processedBytes: ")
            .append(processedBytes)
            .append(", data: ")
            .append(ByteArrays.toHexString(rawData, " "))
            .append(", offset: ")
            .append(offset)
            .append(", length: ")
            .append(length);
          throw new IllegalRawDataException(sb.toString());
        }
        int certificateLength
          = ByteArrays.getInt(rawData, curRelOffset + processedBytes + offset, 3);
        processedBytes += 3;
        if (processedBytes + certificateLength > certificateListLength) {
          StringBuilder sb = new StringBuilder(80);
          sb.append("Can't get a certificate. ")
            .append("The data is too short to build an TlsAbstractCertificateHeader (")
            .append(curRelOffset + processedBytes + certificateLength)
            .append(" bytes). data: ")
            .append(ByteArrays.toHexString(rawData, " "))
            .append(", offset: ")
            .append(offset)
            .append(", length: ")
            .append(length);
          throw new IllegalRawDataException(sb.toString());
        }
//        if (certificateLength > (1 << 24) - 1) {
//          throw new AssertionError();
//        }

        byte[] certificate
          = ByteArrays.getSubArray(
              rawData, curRelOffset + processedBytes + offset, certificateLength
            );
        certificateList.add(certificate);
        processedBytes += certificate.length;
      }
    }

    protected TlsAbstractCertificateHeader(Builder builder) {
      int total = 0;
      for (byte[] cert: builder.certificateList) {
        if (cert.length > (1 << 24) - 1) {
          throw new IllegalArgumentException(
                  "certificate length must be less than (1 << 24) but is: "
                    + cert.length
                );
        }
        this.certificateList.add(ByteArrays.clone(cert));

        total += cert.length;
        if (total > (1 << 24) - 1) {
          throw new IllegalArgumentException(
                  "certificate_list length must be less than (1 << 24)."
                );
        }
      }
    }

    /**
     *
     * @return certificateList
     */
    public List<byte[]> getCertificateList() {
      List<byte[]> list = new ArrayList<byte[]>();
      for (byte[] cert: certificateList) {
        list.add(ByteArrays.clone(cert));
      }
      return list;
    }

    @Override
    protected List<byte[]> getRawFields() {
      List<byte[]> rawFields = new LinkedList<byte[]>();

      int total = 0;
      for (byte[] cert: certificateList) {
        rawFields.add(ByteArrays.toByteArray(cert.length, 3));
        rawFields.add(cert);
        total += 3 + cert.length;
      }
      rawFields.add(0, ByteArrays.toByteArray(total, 3));

      return rawFields;
    }

    @Override
    public int length() {
      int len = 3;
      for (byte[] cert: certificateList) {
        len += 3 + cert.length;
      }
      return len;
    }

    @Override
    protected String buildString() {
      StringBuilder sb = new StringBuilder();
      String ls = System.getProperty("line.separator");

      sb.append("[")
        .append(getHeaderName())
        .append(" (")
        .append(length())
        .append(" bytes)]")
        .append(ls);
      sb.append("  Certificate List: ")
        .append(ls);
      for (byte[] cert: certificateList) {
        sb.append("    ")
          .append(ByteArrays.toHexString(cert, " "))
          .append(ls);
      }

      return sb.toString();
    }

    protected abstract String getHeaderName();

    @Override
    public boolean equals(Object obj) {
      if (obj == this) { return true; }
      if (!this.getClass().isInstance(obj)) { return false; }

      TlsAbstractCertificateHeader other = (TlsAbstractCertificateHeader)obj;

      if (certificateList.size() != other.certificateList.size()) {
        return false;
      }

      Iterator<byte[]> it = other.certificateList.iterator();
      for (byte[] c: certificateList) {
        byte[] oc = it.next();
        if (!Arrays.equals(c, oc)) {
          return false;
        }
      }

      return true;
    }

    @Override
    protected int calcHashCode() {
      int result = 17;
      for (byte[] c: certificateList) {
        result = 31 * result + Arrays.hashCode(c);
      }
      return result;
    }

  }

}
