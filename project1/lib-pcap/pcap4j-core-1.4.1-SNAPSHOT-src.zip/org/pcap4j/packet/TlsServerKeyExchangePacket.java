/*_##########################################################################
  _##
  _##  Copyright (C) 2015  Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.packet;

import org.pcap4j.util.ByteArrays;

/**
 * @author Kaito Yamada
 * @since pcap4j 1.4.0
 */
public final class TlsServerKeyExchangePacket extends TlsAbstractKeyExchangePacket {

  /**
   *
   */
  private static final long serialVersionUID = -5971901312821582144L;

  private final TlsServerKeyExchangeHeader header;

  /**
   * A static factory method.
   * This method validates the arguments by {@link ByteArrays#validateBounds(byte[], int, int)},
   * which may throw exceptions undocumented here.
   *
   * @param rawData
   * @param offset
   * @param length
   * @return a new TlsServerKeyExchangePacket object.
   * @throws IllegalRawDataException
   */
  public static TlsServerKeyExchangePacket newPacket(
    byte[] rawData, int offset, int length
  ) throws IllegalRawDataException {
    ByteArrays.validateBounds(rawData, offset, length);
    TlsServerKeyExchangeHeader header = new TlsServerKeyExchangeHeader(rawData, offset, length);
    return new TlsServerKeyExchangePacket(rawData, offset, length, header);
  }

  private TlsServerKeyExchangePacket(
    byte[] rawData, int offset, int length, TlsServerKeyExchangeHeader header
  ) throws IllegalRawDataException {
    super(rawData, offset, length, header);
    this.header = header;
  }

  private TlsServerKeyExchangePacket(Builder builder) {
    super(builder);
    this.header = new TlsServerKeyExchangeHeader(builder);
  }

  @Override
  public TlsServerKeyExchangeHeader getHeader() {
    return header;
  }

  @Override
  public Builder getBuilder() {
    return new Builder(this);
  }

  /**
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class Builder extends TlsAbstractKeyExchangePacket.Builder {

    /**
     *
     */
    public Builder() {}

    private Builder(TlsServerKeyExchangePacket packet) {
      super(packet);
    }

    @Override
    public TlsServerKeyExchangePacket build() {
      return new TlsServerKeyExchangePacket(this);
    }

  }

  /**
   * Pseudo header to hold a key exchange algorithm.
   *
   * @author Kaito Yamada
   * @since pcap4j 1.4.0
   */
  public static final class TlsServerKeyExchangeHeader extends TlsAbstractKeyExchangeHeader {

    /*
     * struct {
     *     select (KeyExchangeAlgorithm) {
     *         case diffie_hellman:
     *             ServerDHParams params;
     *             Signature signed_params;
     *         case rsa:
     *             ServerRSAParams params;
     *             Signature signed_params;
     *     };
     * } ServerKeyExchange;
     */

    /**
     *
     */
    private static final long serialVersionUID = -2163561438352778562L;

    private TlsServerKeyExchangeHeader(
      byte[] rawData, int offset, int length
    ) throws IllegalRawDataException {
      super(rawData, offset, length);
    }

    private TlsServerKeyExchangeHeader(Builder builder) {
      super(builder);
    }

    @Override
    protected String getHeaderName() {
      return "TLS Server Key Exchange Header";
    }

  }

}
