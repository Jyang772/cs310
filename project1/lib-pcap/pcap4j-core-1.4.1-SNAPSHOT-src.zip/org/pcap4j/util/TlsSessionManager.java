/*_##########################################################################
  _##
  _##  Copyright (C) 2015 Pcap4J.org
  _##
  _##########################################################################
*/

package org.pcap4j.util;

import java.net.InetAddress;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.pcap4j.packet.namednumber.TlsKeyExchangeAlgorithm;
import org.pcap4j.packet.namednumber.TlsSignatureAlgorithm;

/**
 * @author Kaito
 * @since pcap4j 1.4.0
 */
public final class TlsSessionManager {

  private static final TlsSessionManager INSTANCE = new TlsSessionManager();
  private final Map<TlsSessionKey, TlsSession> sessions
    = new ConcurrentHashMap<TlsSessionKey, TlsSession>();

  private TlsSessionManager() {}

  /**
   * @return the singleton instance of TlsSessionManager.
   */
  public static TlsSessionManager getInstance() { return INSTANCE; }

  /**
   * @param key
   * @return a TlsSession object
   */
  public TlsSession getSession(TlsSessionKey key) {
    return sessions.get(key);
  }

  /**
   * @author Kaito
   * @since pcap4j 1.4.0
   */
  public static final class TlsSessionKey {

    private final InetAddress ipAddr;
    private final int port;

    /**
     * @param ipAddr
     * @param port
     */
    public TlsSessionKey(InetAddress ipAddr, int port) {
      if (ipAddr == null) {
         throw new NullPointerException("ipAddr is null");
       }
      this.ipAddr = ipAddr;
      this.port = port;
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + ipAddr.hashCode();
      result = prime * result + port;
      return result;
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (getClass() != obj.getClass()) return false;

      TlsSessionKey other = (TlsSessionKey)obj;
      if (!ipAddr.equals(other.ipAddr)) return false;
      if (port != other.port) return false;
      return true;
    }

  }


  /**
   * @author Kaito
   * @since pcap4j 1.4.0
   */
  public static final class TlsSession {

    private TlsSignatureAlgorithm signatureAlgorithm;
    private TlsKeyExchangeAlgorithm keyExchangeAlgorithm;

    /**
     * @return signatureAlgorithm
     */
    public TlsSignatureAlgorithm getSignatureAlgorithm() {
      return signatureAlgorithm;
    }

    /**
     * @param signatureAlgorithm
     */
    public void setSignatureAlgorithm(TlsSignatureAlgorithm signatureAlgorithm) {
      this.signatureAlgorithm = signatureAlgorithm;
    }

    /**
     * @return keyExchangeAlgorithm
     */
    public TlsKeyExchangeAlgorithm getKeyExchangeAlgorithm() {
      return keyExchangeAlgorithm;
    }

    /**
     * @param keyExchangeAlgorithm
     */
    public void setKeyExchangeAlgorithm(TlsKeyExchangeAlgorithm keyExchangeAlgorithm) {
      this.keyExchangeAlgorithm = keyExchangeAlgorithm;
    }

  }

}
